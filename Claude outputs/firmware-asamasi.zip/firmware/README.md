# Firmware — STM32U585 (Arduino UNO Q)

Arduino C++ sketch for the microcontroller side of the UNO Q. Full description,
module list, message format and bring-up steps: **[`docs/firmware.md`](../docs/firmware.md)**.

```text
firmware/
  solar_field_station/            Arduino sketch folder (App Lab: sketch/)
    solar_field_station.ino       wiring only: builds the objects, setup()/loop()
    src/config/board_config.h     ALL pins / buses / addresses — nothing assigned yet
    src/core/                     portable logic, no Arduino dependency, unit-tested
    src/hal/                      INA226, DS18B20, fan, encoder, ST7920 LCD, Bridge
  test/                           host (PC) tests: make · make json · make hal-syntax
```

**Status:** logic tested on a PC with mocks (30 C++ tests) and against the Python
validator. **Not yet compiled for, flashed to or run on a real UNO Q.**
