#include "messages.h"

#include "json_util.h"

namespace sfs {
namespace {

void meanOrNull(JsonWriter& j, const char* key, const ChannelStat& c, uint8_t dec) {
  j.key(key);
  if (c.has()) j.num(c.mean(), dec);
  else j.null();
}

void stat(JsonWriter& j, const char* key, const ChannelStat& c, uint8_t dec) {
  j.key(key).beginObject();
  j.key("min"); if (c.has()) j.num(c.min, dec); else j.null();
  j.key("max"); if (c.has()) j.num(c.max, dec); else j.null();
  j.key("n").integer(c.n);
  j.endObject();
}

SensorState worst(SensorState a, SensorState b) {
  // a sensor pair (V and I of one INA226) is OK only if both are
  if (a != SensorState::Ok) return a;
  return b;
}

}  // namespace

size_t buildMeasurementJson(const WindowSummary& w, const char* boot_id, char* buf, size_t cap) {
  JsonWriter j(buf, cap);
  const SensorState ina_ref = worst(w.ref_i.state(), w.ref_v.state());
  const SensorState ina_batt = worst(w.batt_v.state(), w.batt_i.state());
  const SensorState t_panel = w.t_panel.state(), t_amb = w.t_ambient.state(), t_case = w.t_case.state();
  const bool all_ok = ina_ref == SensorState::Ok && ina_batt == SensorState::Ok && t_panel == SensorState::Ok &&
                      t_amb == SensorState::Ok && t_case == SensorState::Ok;

  j.beginObject();
  j.key("schema_version").integer(kMeasurementSchema);
  j.key("boot_id").str(boot_id);
  j.key("sequence").integer((long)w.sequence);
  j.key("uptime_ms").integer((long)w.uptime_ms);
  j.key("window_s").num(w.window_s, 1);
  j.key("samples_expected").integer(w.samples_expected);
  j.key("data_completeness").num(w.completeness, 3);
  // window means (units in the key suffix)
  meanOrNull(j, "voltage_v", w.ref_v, 4);
  meanOrNull(j, "current_a", w.ref_i, 6);
  meanOrNull(j, "power_w", w.ref_p, 6);           // reference panel: diagnostic only
  meanOrNull(j, "panel_temperature_c", w.t_panel, 2);
  meanOrNull(j, "ambient_temperature_c", w.t_ambient, 2);
  meanOrNull(j, "case_temperature_c", w.t_case, 2);
  meanOrNull(j, "battery_voltage_v", w.batt_v, 3);
  meanOrNull(j, "battery_current_a", w.batt_i, 4);
  j.key("fan_state").boolean(w.fan_on_at_end);
  j.key("fan_on_s").num(w.fan_on_s, 1);
  j.key("battery_energy_in_wh");
  if (w.batt_energy_valid) j.num(w.batt_energy_in_wh, 5); else j.null();
  j.key("battery_energy_out_wh");
  if (w.batt_energy_valid) j.num(w.batt_energy_out_wh, 5); else j.null();
  j.key("stats").beginObject();
  stat(j, "voltage_v", w.ref_v, 4);
  stat(j, "current_a", w.ref_i, 6);
  stat(j, "panel_temperature_c", w.t_panel, 2);
  stat(j, "ambient_temperature_c", w.t_ambient, 2);
  stat(j, "case_temperature_c", w.t_case, 2);
  stat(j, "battery_voltage_v", w.batt_v, 3);
  stat(j, "battery_current_a", w.batt_i, 4);
  j.endObject();
  j.key("sensor_status").str(all_ok ? "OK" : "DEGRADED");
  j.key("sensors").beginObject();
  j.key("ina_ref").str(sensorStateName(ina_ref));
  j.key("ina_batt").str(sensorStateName(ina_batt));
  j.key("t_panel").str(sensorStateName(t_panel));
  j.key("t_ambient").str(sensorStateName(t_amb));
  j.key("t_case").str(sensorStateName(t_case));
  j.endObject();
  j.endObject();
  return j.ok() ? j.length() : 0;
}

size_t buildMcuConfigJson(const StationSettings& s, char* buf, size_t cap) {
  JsonWriter j(buf, cap);
  j.beginObject();
  j.key("schema_version").integer(kMcuConfigSchema);
  j.key("panel_power_w").num(s.panel_power_w, 1);
  j.key("panel_count").integer(s.panel_count);
  j.endObject();
  return j.ok() ? j.length() : 0;
}

ConfigResult applySetConfig(const char* json, StationSettings& s) {
  double v = 0;
  if (!jsonFindNumber(json, "schema_version", &v) || v != 1) return ConfigResult::Rejected;
  if (jsonFindNumber(json, "panel_power_w", &v) && StationSettings::validPanelPower((float)v))
    s.panel_power_w = (float)v;
  if (jsonFindNumber(json, "panel_count", &v) && v == (long)v && StationSettings::validPanelCount((long)v))
    s.panel_count = (uint16_t)v;
  if (jsonFindNumber(json, "measurement_interval_s", &v) && v == (long)v && StationSettings::validWindow((long)v))
    s.window_s = (uint16_t)v;
  double on = 0, off = 0;
  if (jsonFindNumber(json, "fan_on_c", &on) && jsonFindNumber(json, "fan_off_c", &off) &&
      off <= on - 2.0 && on >= 25 && on <= 70 && off >= 20) {
    s.fan_on_c = (float)on;
    s.fan_off_c = (float)off;
  }
  return ConfigResult::Applied;
}

}  // namespace sfs
