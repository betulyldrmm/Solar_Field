// The firmware's main logic, independent of the hardware:
//   every sample_ms (5 s): read sensors -> fan control -> window aggregator -> screen
//   every window (settings.window_s, default 300 s): summary -> JSON -> Bridge
// Windows that could not be delivered (Linux still booting, Bridge busy) wait
// in a small queue and are retried; the oldest are dropped only when it is full.
// Windows are turned into JSON only when sent, after Linux has given this boot
// its boot id — measuring starts immediately, independent of Linux.
#pragma once
#include <stdint.h>

#include "display_model.h"
#include "fan_controller.h"
#include "menu.h"
#include "messages.h"
#include "ports.h"
#include "settings.h"
#include "window_aggregator.h"

namespace sfs {

struct StationDeps {
  IPowerMonitor* ref_monitor;
  IPowerMonitor* batt_monitor;
  ITemperatureSensors* temps;
  IFanOutput* fan;
  IInput* input;
  IDisplay* display;
  ILink* link;
};

class StationApp {
 public:
  static constexpr uint32_t kSampleMs = 5000;
  static constexpr uint8_t kQueueSize = 12;          // 1 hour of 5-min windows
  static constexpr uint32_t kRetryMs = 10000;
  static constexpr uint32_t kDisplayMs = 500;

  explicit StationApp(const StationDeps& deps) : d_(deps) {}

  void begin(uint32_t now_ms);
  void loop(uint32_t now_ms);                   // call as often as possible
  bool onSetConfig(const char* json);           // Bridge handler (Linux -> STM32)

  // --- inspection (tests, debug) ---
  const StationSettings& settings() const { return settings_; }
  const WindowSummary* lastWindow() const { return have_last_window_ ? &last_window_ : nullptr; }
  uint8_t pending() const { return q_count_; }
  uint32_t droppedWindows() const { return dropped_; }
  bool fanOn() const { return fan_ctl_.on(); }
  FanReason fanReason() const { return fan_ctl_.reason(); }
  const Menu& menu() const { return menu_; }
  const char* bootId() const { return boot_id_; }

 private:
  void takeSample(uint32_t now_ms);
  void closeWindow(uint32_t now_ms);
  void flushQueue(uint32_t now_ms);
  void applyRuntimeSettings();
  void refreshDisplay(uint32_t now_ms, bool force);
  void sendConfigToLinux();

  StationDeps d_;
  StationSettings settings_;
  FanController fan_ctl_;
  WindowAggregator agg_;
  Menu menu_;
  Sample last_sample_;
  bool have_sample_ = false;
  WindowSummary last_window_;
  bool have_last_window_ = false;
  WindowSummary queue_[kQueueSize];
  uint8_t q_head_ = 0, q_count_ = 0;
  uint32_t dropped_ = 0;
  uint32_t next_sample_ms_ = 0;
  uint32_t last_retry_ms_ = 0;
  uint32_t last_display_ms_ = 0;
  bool linux_ok_ = false;
  bool config_dirty_ = false;  // encoder edit not yet confirmed by Linux
  char boot_id_[9] = {0};      // empty until Linux assigned one
  char json_[kMeasurementJsonMax];
};

}  // namespace sfs
