#include "fan_controller.h"

namespace sfs {

bool FanController::setThresholds(float on_c, float off_c) {
  if (!(off_c <= on_c - 2.0f) || on_c > cfg_.emergency_c) return false;
  cfg_.on_c = on_c;
  cfg_.off_c = off_c;
  return true;
}

void FanController::set(bool on, FanReason why, uint32_t now_ms) {
  if (on != on_) {
    last_switch_ms_ = now_ms;
    switched_once_ = true;
  }
  on_ = on;
  reason_ = why;
}

bool FanController::update(const Reading& t, uint32_t now_ms) {
  if (!t.ok()) {
    if (bad_count_ < 255) ++bad_count_;
    if (bad_count_ >= cfg_.failsafe_after) set(true, FanReason::SensorFailsafe, now_ms);
    return on_;  // a short glitch keeps the current state
  }
  bad_count_ = 0;
  if (t.value >= cfg_.emergency_c) {
    set(true, FanReason::Emergency, now_ms);
  } else if (t.value >= cfg_.on_c) {
    set(true, FanReason::Hysteresis, now_ms);
  } else if (on_ && t.value <= cfg_.off_c) {
    const bool may_switch = !switched_once_ || (uint32_t)(now_ms - last_switch_ms_) >= cfg_.min_switch_ms;
    if (may_switch) set(false, FanReason::Off, now_ms);
  } else if (on_ && reason_ == FanReason::SensorFailsafe) {
    reason_ = FanReason::Hysteresis;  // sensor back, between thresholds: keep running until off_c
  }
  return on_;
}

}  // namespace sfs
