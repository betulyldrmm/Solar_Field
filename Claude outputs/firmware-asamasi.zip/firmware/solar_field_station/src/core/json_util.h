// Minimal JSON helpers without heap or floating-point printf (printf float
// support is not guaranteed on every embedded C library).
#pragma once
#include <stddef.h>
#include <stdint.h>

namespace sfs {

class JsonWriter {
 public:
  JsonWriter(char* buf, size_t cap);
  JsonWriter& beginObject();
  JsonWriter& endObject();
  JsonWriter& key(const char* k);                       // writes "k": (with comma if needed)
  JsonWriter& num(double v, uint8_t decimals);          // fixed-point, rounds half away from zero
  JsonWriter& integer(long v);
  JsonWriter& boolean(bool v);
  JsonWriter& null();
  JsonWriter& str(const char* s);                       // escapes " and \ ; drops control chars
  bool ok() const { return !overflow_; }
  size_t length() const { return len_; }
  const char* c_str() const { return buf_; }

 private:
  void raw(const char* s);
  void ch(char c);
  void comma();
  char* buf_;
  size_t cap_;
  size_t len_ = 0;
  bool overflow_ = false;
  bool need_comma_ = false;
};

// Finds a top-level numeric value "key": <number> in a flat JSON object.
// Returns false if the key is missing or the value is not a number.
bool jsonFindNumber(const char* json, const char* key, double* out);

}  // namespace sfs
