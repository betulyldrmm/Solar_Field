// 5-second samples -> 5-minute window summary (mean / min / max / n per channel,
// battery energy in and out, fan run time, data completeness).
//
// Units: V, A, °C, Wh, s. The reference panel is short-circuited, so its
// current is an irradiance proxy and its V*I is only a diagnostic — the
// electrical energy that is really measured is the battery side (INA226 #2).
#pragma once
#include <stdint.h>

#include "types.h"

namespace sfs {

struct ChannelStat {
  uint16_t n = 0;
  float sum = 0.0f;
  float min = 0.0f;
  float max = 0.0f;
  SensorState last_bad = SensorState::NotInstalled;  // reported when n == 0

  void reset();
  void add(const Reading& r);
  void addValue(float v);
  bool has() const { return n > 0; }
  float mean() const { return n ? sum / n : 0.0f; }
  SensorState state() const { return n ? SensorState::Ok : last_bad; }
};

struct WindowSummary {
  uint32_t sequence = 0;
  uint32_t uptime_ms = 0;          // at window end
  float window_s = 0.0f;           // actual length
  uint16_t samples_expected = 0;
  uint16_t samples_taken = 0;
  float completeness = 0.0f;       // valid reference-current samples / expected (0..1)
  ChannelStat ref_v, ref_i, ref_p, batt_v, batt_i, t_panel, t_ambient, t_case;
  double batt_energy_in_wh = 0.0;  // charging (battery power > 0)
  double batt_energy_out_wh = 0.0; // discharging
  bool batt_energy_valid = false;  // false if no valid battery V and I sample at all
  float fan_on_s = 0.0f;
  bool fan_on_at_end = false;
};

class WindowAggregator {
 public:
  void configure(uint32_t window_ms, uint32_t sample_ms);
  void begin(uint32_t now_ms);
  void addSample(const Sample& s, uint32_t now_ms);
  bool windowDue(uint32_t now_ms) const { return (uint32_t)(now_ms - start_ms_) >= window_ms_; }
  // Finalises the current window, returns it and starts the next one at now_ms.
  WindowSummary close(uint32_t now_ms);

  uint32_t windowMs() const { return window_ms_; }
  uint32_t sampleMs() const { return sample_ms_; }
  const WindowSummary& current() const { return cur_; }

 private:
  uint32_t window_ms_ = 300000;
  uint32_t sample_ms_ = 5000;
  uint32_t start_ms_ = 0;
  uint32_t last_sample_ms_ = 0;
  bool have_last_ = false;
  uint32_t next_sequence_ = 1;
  WindowSummary cur_;
};

}  // namespace sfs
