// STM32 <-> Linux message formats (JSON text over the UNO Q Bridge).
//
//   measurement  (STM32 -> Linux): schema v2 window summary,
//                checked by backend/app/services/validator.py
//   mcu_config   (STM32 -> Linux): panel power / count edited with the encoder
//   set_config   (Linux -> STM32): HardwareBridgeAdapter.config_for_mcu()
#pragma once
#include <stddef.h>

#include "settings.h"
#include "window_aggregator.h"

namespace sfs {

constexpr int kMeasurementSchema = 2;
constexpr int kMcuConfigSchema = 1;
constexpr size_t kMeasurementJsonMax = 1024;   // typical message ~750 bytes

// Returns the JSON length, or 0 if the buffer was too small.
size_t buildMeasurementJson(const WindowSummary& w, const char* boot_id, char* buf, size_t cap);
size_t buildMcuConfigJson(const StationSettings& s, char* buf, size_t cap);

enum class ConfigResult { Applied, Rejected };
// Applies every valid field of a set_config message to `s`. A field that is
// out of range is ignored (the rest still applies); a wrong schema rejects all.
// The fan pair is applied only if off <= on - 2 °C (same rule as the backend).
ConfigResult applySetConfig(const char* json, StationSettings& s);

}  // namespace sfs
