#include "input.h"

namespace sfs {

int8_t QuadratureDecoder::update(bool a, bool b) {
  // index = old<<2 | new ; +1 / -1 for valid single steps, 0 otherwise
  static const int8_t kTable[16] = {0, -1, +1, 0, +1, 0, 0, -1, -1, 0, 0, +1, 0, +1, -1, 0};
  const uint8_t now = (uint8_t)((a << 1) | b);
  accum_ += kTable[(state_ << 2) | now];
  state_ = now;
  int8_t detents = 0;
  while (accum_ >= per_detent_) { accum_ -= per_detent_; ++detents; }
  while (accum_ <= -per_detent_) { accum_ += per_detent_; --detents; }
  return detents;
}

ButtonEvent ButtonDebouncer::update(bool pressed, uint32_t now_ms) {
  if (pressed != raw_) {
    raw_ = pressed;
    raw_since_ = now_ms;
  }
  ButtonEvent ev = ButtonEvent::None;
  if (raw_ != stable_ && (uint32_t)(now_ms - raw_since_) >= debounce_ms_) {
    stable_ = raw_;
    if (stable_) {
      pressed_since_ = now_ms;
      long_fired_ = false;
    } else if (!long_fired_) {
      ev = ButtonEvent::Click;  // released before the long-press time
    }
  }
  if (stable_ && !long_fired_ && (uint32_t)(now_ms - pressed_since_) >= long_ms_) {
    long_fired_ = true;
    ev = ButtonEvent::LongPress;
  }
  return ev;
}

}  // namespace sfs
