#include "types.h"

namespace sfs {

const char* sensorStateName(SensorState s) {
  switch (s) {
    case SensorState::Ok: return "OK";
    case SensorState::NotInstalled: return "NOT_INSTALLED";
    case SensorState::Disconnected: return "DISCONNECTED";
    case SensorState::Error: return "ERROR";
  }
  return "ERROR";
}

}  // namespace sfs
