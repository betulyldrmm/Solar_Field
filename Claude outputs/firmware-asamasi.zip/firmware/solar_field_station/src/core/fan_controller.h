// Case-temperature fan control with hysteresis and fail-safe behaviour.
//
// * Turning ON is immediate (safety first); turning OFF waits min_switch_ms
//   after the last switch, so the fan does not chatter around the threshold.
// * Case sensor missing/failed for `failsafe_after` samples in a row -> fan ON.
//   A fan running without need costs a little energy; an overheated case can
//   cost the battery and the electronics.
// * Above emergency_c the fan is forced ON whatever the hysteresis says.
#pragma once
#include <stdint.h>

#include "types.h"

namespace sfs {

struct FanConfig {
  float on_c = 40.0f;
  float off_c = 35.0f;
  float emergency_c = 70.0f;
  uint32_t min_switch_ms = 30000;
  uint8_t failsafe_after = 3;
};

enum class FanReason : uint8_t { Off, Hysteresis, SensorFailsafe, Emergency };

class FanController {
 public:
  explicit FanController(const FanConfig& cfg = FanConfig()) : cfg_(cfg) {}
  // Returns false (and keeps the old thresholds) if off_c is not at least 2 °C below on_c.
  bool setThresholds(float on_c, float off_c);
  bool update(const Reading& case_temp, uint32_t now_ms);
  bool on() const { return on_; }
  FanReason reason() const { return reason_; }
  const FanConfig& config() const { return cfg_; }

 private:
  void set(bool on, FanReason why, uint32_t now_ms);
  FanConfig cfg_;
  bool on_ = false;
  FanReason reason_ = FanReason::Off;
  uint8_t bad_count_ = 0;
  uint32_t last_switch_ms_ = 0;
  bool switched_once_ = false;
};

}  // namespace sfs
