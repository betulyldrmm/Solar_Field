// Rotary encoder decoding and push-button debouncing (pure logic; the HAL
// feeds raw pin levels). Polling, so it does not depend on which UNO Q pins
// support interrupts.
#pragma once
#include <stdint.h>

namespace sfs {

// Gray-code quadrature decoder. Invalid jumps (bounce, missed state) are ignored.
class QuadratureDecoder {
 public:
  explicit QuadratureDecoder(uint8_t steps_per_detent = 4) : per_detent_(steps_per_detent ? steps_per_detent : 1) {}
  void reset(bool a, bool b) { state_ = (uint8_t)((a << 1) | b); accum_ = 0; }
  // Returns detents moved since the previous call (+ clockwise, - counter-clockwise).
  int8_t update(bool a, bool b);

 private:
  uint8_t per_detent_;
  uint8_t state_ = 0;
  int8_t accum_ = 0;
};

enum class ButtonEvent : uint8_t { None, Click, LongPress };

// Debounced button; `pressed` is the logical state (HAL handles pull-up inversion).
class ButtonDebouncer {
 public:
  ButtonDebouncer(uint16_t debounce_ms = 30, uint16_t long_ms = 800) : debounce_ms_(debounce_ms), long_ms_(long_ms) {}
  ButtonEvent update(bool pressed, uint32_t now_ms);

 private:
  uint16_t debounce_ms_, long_ms_;
  bool raw_ = false, stable_ = false, long_fired_ = false;
  uint32_t raw_since_ = 0, pressed_since_ = 0;
};

struct InputEvent {
  int8_t delta = 0;
  ButtonEvent button = ButtonEvent::None;
  bool any() const { return delta != 0 || button != ButtonEvent::None; }
};

}  // namespace sfs
