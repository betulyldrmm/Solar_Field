#include "window_aggregator.h"

namespace sfs {

void ChannelStat::reset() { *this = ChannelStat(); }

void ChannelStat::addValue(float v) {
  if (n == 0) {
    min = max = v;
  } else {
    if (v < min) min = v;
    if (v > max) max = v;
  }
  sum += v;
  ++n;
}

void ChannelStat::add(const Reading& r) {
  if (r.ok()) addValue(r.value);
  else last_bad = r.state;
}

void WindowAggregator::configure(uint32_t window_ms, uint32_t sample_ms) {
  sample_ms_ = sample_ms ? sample_ms : 5000;
  window_ms_ = window_ms >= sample_ms_ ? window_ms : sample_ms_;
}

void WindowAggregator::begin(uint32_t now_ms) {
  uint32_t seq = next_sequence_;
  cur_ = WindowSummary();
  cur_.sequence = seq;
  start_ms_ = now_ms;
  have_last_ = false;
}

void WindowAggregator::addSample(const Sample& s, uint32_t now_ms) {
  // Time this sample stands for: real spacing, capped so a stall/gap is not
  // counted as energy ("gaps are not production").
  uint32_t dt_ms = sample_ms_;
  if (have_last_) {
    uint32_t d = now_ms - last_sample_ms_;
    dt_ms = d > 2 * sample_ms_ ? sample_ms_ : d;
  }
  last_sample_ms_ = now_ms;
  have_last_ = true;
  const double dt_h = dt_ms / 3600000.0;

  cur_.samples_taken++;
  cur_.ref_v.add(s.ref.bus_v);
  cur_.ref_i.add(s.ref.current_a);
  if (s.ref.bus_v.ok() && s.ref.current_a.ok()) cur_.ref_p.addValue(s.ref.bus_v.value * s.ref.current_a.value);
  cur_.batt_v.add(s.batt.bus_v);
  cur_.batt_i.add(s.batt.current_a);
  if (s.batt.bus_v.ok() && s.batt.current_a.ok()) {
    const double p_w = (double)s.batt.bus_v.value * s.batt.current_a.value;
    if (p_w >= 0) cur_.batt_energy_in_wh += p_w * dt_h;
    else cur_.batt_energy_out_wh += -p_w * dt_h;
    cur_.batt_energy_valid = true;
  }
  cur_.t_panel.add(s.t_panel);
  cur_.t_ambient.add(s.t_ambient);
  cur_.t_case.add(s.t_case);
  if (s.fan_on) cur_.fan_on_s += dt_ms / 1000.0f;
  cur_.fan_on_at_end = s.fan_on;
}

WindowSummary WindowAggregator::close(uint32_t now_ms) {
  WindowSummary out = cur_;
  out.window_s = (uint32_t)(now_ms - start_ms_) / 1000.0f;
  out.uptime_ms = now_ms;
  out.samples_expected = (uint16_t)((window_ms_ + sample_ms_ / 2) / sample_ms_);
  float c = out.samples_expected ? (float)out.ref_i.n / out.samples_expected : 0.0f;
  out.completeness = c > 1.0f ? 1.0f : c;
  next_sequence_ = out.sequence + 1;
  begin(now_ms);
  return out;
}

}  // namespace sfs
