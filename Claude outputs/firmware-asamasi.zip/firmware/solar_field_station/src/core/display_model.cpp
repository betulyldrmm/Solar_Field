#include "display_model.h"

#include <math.h>
#include <stdio.h>
#include <string.h>

namespace sfs {

size_t formatFixed(char* buf, size_t cap, float v, uint8_t decimals) {
  if (!cap) return 0;
  if (!isfinite(v)) { snprintf(buf, cap, "--"); return strlen(buf); }
  long scale = 1;
  for (uint8_t i = 0; i < decimals; ++i) scale *= 10;
  long scaled = lroundf(fabsf(v) * scale);
  const char* sign = (v < 0 && scaled) ? "-" : "";
  if (decimals) snprintf(buf, cap, "%s%ld.%0*ld", sign, scaled / scale, (int)decimals, scaled % scale);
  else snprintf(buf, cap, "%s%ld", sign, scaled);
  return strlen(buf);
}

namespace {

void put(DisplayLines& d, uint8_t row, const char* text) {
  strncpy(d.line[row], text, DisplayLines::kCols);
  d.line[row][DisplayLines::kCols] = '\0';
}

// value or "--" if the reading is not OK
void fx(char* buf, size_t cap, const Reading& r, float scale, uint8_t dec) {
  if (r.ok()) formatFixed(buf, cap, r.value * scale, dec);
  else snprintf(buf, cap, "--");
}

void fxStat(char* buf, size_t cap, const ChannelStat& c, float v, float scale, uint8_t dec) {
  if (c.has()) formatFixed(buf, cap, v * scale, dec);
  else snprintf(buf, cap, "--");
}

}  // namespace

void buildDisplay(const DisplayState& st, DisplayLines& d) {
  for (uint8_t i = 0; i < DisplayLines::kLines; ++i) d.line[i][0] = '\0';
  char t[64];  // put() cuts every line to the 21 visible columns
  char a[16], b[16];
  const Menu* m = st.menu;
  const StationSettings* s = st.settings;

  if (m && m->state() == MenuState::EditPower) {
    put(d, 0, "AYAR 1/2");
    put(d, 1, "Panel gucu");
    formatFixed(a, sizeof a, m->draftPower(), 0);
    snprintf(t, sizeof t, "  > %s W <", a); put(d, 2, t);
    put(d, 4, "Cevir: degistir");
    put(d, 5, "Tikla: ileri");
    return;
  }
  if (m && m->state() == MenuState::EditCount) {
    put(d, 0, "AYAR 2/2");
    put(d, 1, "Panel sayisi");
    snprintf(t, sizeof t, "  > %u <", (unsigned)m->draftCount()); put(d, 2, t);
    formatFixed(a, sizeof a, m->draftPower() * m->draftCount() / 1000.0f, 2);
    snprintf(t, sizeof t, "Kurulu %s kWp", a); put(d, 3, t);
    put(d, 4, "Tikla: kaydet");
    put(d, 5, "Uzun bas: iptal");
    return;
  }

  const uint8_t page = m ? m->page() : 0;
  if (page == 0) {  // live values
    snprintf(t, sizeof t, "CANLI   Linux:%s", st.linux_ok ? "OK" : "--"); put(d, 0, t);
    const Sample* x = st.last_sample;
    if (!x) { put(d, 2, "Ilk olcum bekleniyor"); return; }
    fx(a, sizeof a, x->ref.current_a, 1000.0f, 1);
    snprintf(t, sizeof t, "Isc  %s mA", a); put(d, 1, t);
    fx(a, sizeof a, x->t_panel, 1, 1); fx(b, sizeof b, x->t_ambient, 1, 1);
    snprintf(t, sizeof t, "Pnl %sC Ort %sC", a, b); put(d, 2, t);
    fx(a, sizeof a, x->t_case, 1, 1);
    snprintf(t, sizeof t, "Kasa %sC Fan %s", a, x->fan_on ? "ACIK" : "kapali"); put(d, 3, t);
    fx(a, sizeof a, x->batt.bus_v, 1, 2); fx(b, sizeof b, x->batt.current_a, 1, 2);
    snprintf(t, sizeof t, "Pil %sV %sA", a, b); put(d, 4, t);
    if (st.open_window) {
      snprintf(t, sizeof t, "Pencere #%lu %u ornek", (unsigned long)st.open_window->sequence,
               (unsigned)st.open_window->samples_taken);
      put(d, 5, t);
    }
  } else if (page == 1) {  // last finished window
    const WindowSummary* w = st.last_window;
    if (!w) { put(d, 0, "SON PENCERE"); put(d, 2, "Henuz yok (5 dk)"); return; }
    snprintf(t, sizeof t, "SON PENCERE #%lu", (unsigned long)w->sequence); put(d, 0, t);
    fxStat(a, sizeof a, w->ref_i, w->ref_i.mean(), 1000.0f, 1);
    snprintf(t, sizeof t, "Isc ort %s mA", a); put(d, 1, t);
    fxStat(a, sizeof a, w->ref_i, w->ref_i.min, 1000.0f, 1); fxStat(b, sizeof b, w->ref_i, w->ref_i.max, 1000.0f, 1);
    snprintf(t, sizeof t, "min %s max %s", a, b); put(d, 2, t);
    formatFixed(a, sizeof a, w->completeness * 100.0f, 0);
    snprintf(t, sizeof t, "Tamlik %%%s", a); put(d, 3, t);
    if (w->batt_energy_valid) {
      formatFixed(a, sizeof a, (float)w->batt_energy_in_wh, 3);
      formatFixed(b, sizeof b, (float)w->batt_energy_out_wh, 3);
      snprintf(t, sizeof t, "Sarj %s Wh", a); put(d, 4, t);
      snprintf(t, sizeof t, "Desarj %s Wh", b); put(d, 5, t);
    } else {
      put(d, 4, "Pil enerjisi: --");
    }
  } else {  // system
    put(d, 0, "SISTEM");
    if (s) {
      formatFixed(a, sizeof a, s->panel_power_w, 0);
      snprintf(t, sizeof t, "Panel %s W x %u", a, (unsigned)s->panel_count); put(d, 1, t);
      formatFixed(b, sizeof b, s->installedKwp(), 2);
      snprintf(t, sizeof t, "Kurulu %s kWp", b); put(d, 2, t);
      snprintf(t, sizeof t, "Kayit araligi %us", (unsigned)s->window_s); put(d, 3, t);
    }
    snprintf(t, sizeof t, "Linux %s bekleyen %u", st.linux_ok ? "OK" : "YOK", (unsigned)st.pending); put(d, 4, t);
    put(d, 5, "Tikla: panel ayari");
  }
}

}  // namespace sfs
