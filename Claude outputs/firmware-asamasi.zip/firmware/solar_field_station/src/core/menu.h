// Encoder menu: browse status pages, edit panel power and panel count.
//
//   Home pages (rotate) --click--> Edit power --click--> Edit count --click--> commit
//   long press or 30 s without input while editing -> cancel (nothing changes)
#pragma once
#include <stdint.h>

#include "input.h"
#include "settings.h"

namespace sfs {

enum class MenuState : uint8_t { Home, EditPower, EditCount };

class Menu {
 public:
  static constexpr uint8_t kHomePages = 3;
  static constexpr uint32_t kEditTimeoutMs = 30000;
  static constexpr float kPowerStepW = 5.0f;
  static constexpr uint8_t kFastFactor = 10;       // when turning fast
  static constexpr uint32_t kFastWithinMs = 80;

  // Returns true when an edit was committed; the new values are in `s`.
  bool handle(const InputEvent& ev, StationSettings& s, uint32_t now_ms);
  void tick(uint32_t now_ms);  // edit timeout

  MenuState state() const { return state_; }
  uint8_t page() const { return page_; }
  float draftPower() const { return draft_power_; }
  uint16_t draftCount() const { return draft_count_; }

 private:
  int stepFactor(uint32_t now_ms);
  MenuState state_ = MenuState::Home;
  uint8_t page_ = 0;
  float draft_power_ = 0;
  uint16_t draft_count_ = 0;
  uint32_t last_input_ms_ = 0;
  uint32_t last_turn_ms_ = 0;
  bool turned_before_ = false;
};

}  // namespace sfs
