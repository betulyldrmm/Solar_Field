#include "menu.h"

namespace sfs {

int Menu::stepFactor(uint32_t now_ms) {
  const bool fast = turned_before_ && (uint32_t)(now_ms - last_turn_ms_) < kFastWithinMs;
  last_turn_ms_ = now_ms;
  turned_before_ = true;
  return fast ? kFastFactor : 1;
}

bool Menu::handle(const InputEvent& ev, StationSettings& s, uint32_t now_ms) {
  if (!ev.any()) return false;
  last_input_ms_ = now_ms;
  if (ev.button == ButtonEvent::LongPress) {
    state_ = MenuState::Home;  // cancel
    return false;
  }
  switch (state_) {
    case MenuState::Home:
      if (ev.delta) page_ = (uint8_t)((page_ + kHomePages + (ev.delta % kHomePages)) % kHomePages);
      if (ev.button == ButtonEvent::Click) {
        draft_power_ = s.panel_power_w;
        draft_count_ = s.panel_count;
        state_ = MenuState::EditPower;
      }
      return false;
    case MenuState::EditPower: {
      if (ev.delta) {
        float p = draft_power_ + ev.delta * kPowerStepW * stepFactor(now_ms);
        if (p < StationSettings::kPanelPowerMinW) p = StationSettings::kPanelPowerMinW;
        if (p > StationSettings::kPanelPowerMaxW) p = StationSettings::kPanelPowerMaxW;
        draft_power_ = p;
      }
      if (ev.button == ButtonEvent::Click) state_ = MenuState::EditCount;
      return false;
    }
    case MenuState::EditCount: {
      if (ev.delta) {
        long n = (long)draft_count_ + (long)ev.delta * stepFactor(now_ms);
        if (n < StationSettings::kPanelCountMin) n = StationSettings::kPanelCountMin;
        if (n > StationSettings::kPanelCountMax) n = StationSettings::kPanelCountMax;
        draft_count_ = (uint16_t)n;
      }
      if (ev.button == ButtonEvent::Click) {
        state_ = MenuState::Home;
        if (draft_power_ != s.panel_power_w || draft_count_ != s.panel_count) {
          s.panel_power_w = draft_power_;
          s.panel_count = draft_count_;
          return true;
        }
      }
      return false;
    }
  }
  return false;
}

void Menu::tick(uint32_t now_ms) {
  if (state_ != MenuState::Home && (uint32_t)(now_ms - last_input_ms_) >= kEditTimeoutMs) state_ = MenuState::Home;
}

}  // namespace sfs
