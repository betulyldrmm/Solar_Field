#include "json_util.h"

#include <math.h>
#include <stdlib.h>
#include <string.h>

namespace sfs {

JsonWriter::JsonWriter(char* buf, size_t cap) : buf_(buf), cap_(cap) {
  if (cap_) buf_[0] = '\0';
}

void JsonWriter::ch(char c) {
  if (len_ + 1 >= cap_) { overflow_ = true; return; }
  buf_[len_++] = c;
  buf_[len_] = '\0';
}

void JsonWriter::raw(const char* s) { while (*s) ch(*s++); }

void JsonWriter::comma() {
  if (need_comma_) ch(',');
  need_comma_ = false;
}

JsonWriter& JsonWriter::beginObject() { comma(); ch('{'); need_comma_ = false; return *this; }
JsonWriter& JsonWriter::endObject() { ch('}'); need_comma_ = true; return *this; }

JsonWriter& JsonWriter::key(const char* k) {
  comma();
  str(k);
  need_comma_ = false;
  ch(':');
  return *this;
}

JsonWriter& JsonWriter::str(const char* s) {
  comma();
  ch('"');
  for (; *s; ++s) {
    if (*s == '"' || *s == '\\') { ch('\\'); ch(*s); }
    else if ((unsigned char)*s >= 0x20) ch(*s);
  }
  ch('"');
  need_comma_ = true;
  return *this;
}

JsonWriter& JsonWriter::integer(long v) {
  comma();
  char tmp[24];
  int i = 0;
  unsigned long u = v < 0 ? (unsigned long)(-(v + 1)) + 1 : (unsigned long)v;
  do { tmp[i++] = (char)('0' + u % 10); u /= 10; } while (u && i < 22);
  if (v < 0) ch('-');
  while (i) ch(tmp[--i]);
  need_comma_ = true;
  return *this;
}

JsonWriter& JsonWriter::num(double v, uint8_t decimals) {
  if (!isfinite(v)) return null();  // never emit NaN/Inf (invalid JSON)
  if (decimals > 9) decimals = 9;
  double scale = 1.0;
  for (uint8_t i = 0; i < decimals; ++i) scale *= 10.0;
  double scaled = fabs(v) * scale + 0.5;
  if (scaled > 9.0e18) return null();
  unsigned long long u = (unsigned long long)scaled;
  unsigned long long ip = u / (unsigned long long)scale;
  unsigned long long fp = u % (unsigned long long)scale;
  comma();
  if (v < 0 && u != 0) ch('-');
  char tmp[24];
  int i = 0;
  do { tmp[i++] = (char)('0' + ip % 10); ip /= 10; } while (ip && i < 22);
  while (i) ch(tmp[--i]);
  if (decimals) {
    ch('.');
    char frac[10];
    for (int k = decimals - 1; k >= 0; --k) { frac[k] = (char)('0' + fp % 10); fp /= 10; }
    for (uint8_t k = 0; k < decimals; ++k) ch(frac[k]);
  }
  need_comma_ = true;
  return *this;
}

JsonWriter& JsonWriter::boolean(bool v) { comma(); raw(v ? "true" : "false"); need_comma_ = true; return *this; }
JsonWriter& JsonWriter::null() { comma(); raw("null"); need_comma_ = true; return *this; }

bool jsonFindNumber(const char* json, const char* key, double* out) {
  if (!json || !key) return false;
  const size_t klen = strlen(key);
  for (const char* p = strchr(json, '"'); p; p = strchr(p + 1, '"')) {
    if (strncmp(p + 1, key, klen) == 0 && p[1 + klen] == '"') {
      const char* q = p + 2 + klen;
      while (*q == ' ' || *q == '\t' || *q == '\n' || *q == '\r') ++q;
      if (*q != ':') continue;
      ++q;
      while (*q == ' ' || *q == '\t' || *q == '\n' || *q == '\r') ++q;
      char* end = nullptr;
      double v = strtod(q, &end);
      if (end == q || !isfinite(v)) return false;
      *out = v;
      return true;
    }
  }
  return false;
}

}  // namespace sfs
