// Interfaces between the portable core and the hardware layer (src/hal).
// The real implementations talk to I2C/1-Wire/GPIO/Bridge; the unit tests
// (firmware/test) use mocks. Nothing here knows about pins.
#pragma once
#include <stdint.h>

#include "input.h"
#include "types.h"

namespace sfs {

class IPowerMonitor {  // one INA226
 public:
  virtual ~IPowerMonitor() {}
  virtual bool begin() = 0;
  virtual PowerReading read() = 0;
};

class ITemperatureSensors {  // DS18B20 bus, three roles
 public:
  virtual ~ITemperatureSensors() {}
  virtual void begin() = 0;
  virtual void startConversion() = 0;  // results are read at the next sample (>= 750 ms later)
  virtual void read(Reading& panel, Reading& ambient, Reading& case_t) = 0;
};

class IFanOutput {
 public:
  virtual ~IFanOutput() {}
  virtual void set(bool on) = 0;
};

class IInput {
 public:
  virtual ~IInput() {}
  virtual InputEvent poll(uint32_t now_ms) = 0;
};

struct DisplayLines {
  static constexpr uint8_t kLines = 6;
  static constexpr uint8_t kCols = 21;  // 128 px / 6 px font
  char line[kLines][kCols + 1];
};

class IDisplay {
 public:
  virtual ~IDisplay() {}
  virtual void show(const DisplayLines& d) = 0;
};

class ILink {  // UNO Q Bridge to the Linux side
 public:
  virtual ~ILink() {}
  // Asks Linux for a fresh random boot id (8 hex chars). The STM32 has no
  // verified entropy source, and a boot id that repeats after a reboot would
  // make the database drop new windows as duplicates of (boot_id, sequence).
  virtual bool requestBootId(char* out, uint8_t cap) = 0;
  // true only when the Linux side confirmed it stored the message
  virtual bool sendMeasurement(const char* json) = 0;
  virtual bool sendConfig(const char* json) = 0;
};

}  // namespace sfs
