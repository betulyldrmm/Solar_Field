#include "station_app.h"

#include <string.h>

namespace sfs {

void StationApp::begin(uint32_t now_ms) {
  boot_id_[0] = '\0';
  if (d_.ref_monitor) d_.ref_monitor->begin();
  if (d_.batt_monitor) d_.batt_monitor->begin();
  if (d_.temps) { d_.temps->begin(); d_.temps->startConversion(); }
  if (d_.fan) d_.fan->set(false);
  applyRuntimeSettings();
  next_sample_ms_ = now_ms + 1000;  // first sample after the first 1-Wire conversion (750 ms)
  // The window starts one sample period before the first sample, so a window
  // always holds exactly window_s / 5 s samples.
  agg_.begin(next_sample_ms_ - kSampleMs);
  refreshDisplay(now_ms, true);
}

void StationApp::applyRuntimeSettings() {
  agg_.configure((uint32_t)settings_.window_s * 1000u, kSampleMs);
  fan_ctl_.setThresholds(settings_.fan_on_c, settings_.fan_off_c);
}

bool StationApp::onSetConfig(const char* json) {
  StationSettings s = settings_;
  if (applySetConfig(json, s) != ConfigResult::Applied) return false;
  settings_ = s;
  config_dirty_ = false;  // Linux now holds the authoritative values
  applyRuntimeSettings(); // a new window length also applies to the window in progress
  return true;
}

void StationApp::loop(uint32_t now_ms) {
  if (d_.input) {
    InputEvent ev = d_.input->poll(now_ms);
    if (ev.any()) {
      if (menu_.handle(ev, settings_, now_ms)) {
        config_dirty_ = true;
        sendConfigToLinux();
      }
      refreshDisplay(now_ms, true);
    }
  }
  menu_.tick(now_ms);

  if ((int32_t)(now_ms - next_sample_ms_) >= 0) {
    takeSample(now_ms);
    next_sample_ms_ += kSampleMs;
    if ((int32_t)(now_ms - next_sample_ms_) >= 0) next_sample_ms_ = now_ms + kSampleMs;  // fell behind: resync
    if (agg_.windowDue(now_ms)) closeWindow(now_ms);
  }

  if (q_count_ && (uint32_t)(now_ms - last_retry_ms_) >= kRetryMs) flushQueue(now_ms);
  if (config_dirty_ && (uint32_t)(now_ms - last_retry_ms_) >= kRetryMs) sendConfigToLinux();
  refreshDisplay(now_ms, false);
}

void StationApp::takeSample(uint32_t now_ms) {
  Sample s;
  if (d_.ref_monitor) s.ref = d_.ref_monitor->read();
  if (d_.batt_monitor) s.batt = d_.batt_monitor->read();
  if (d_.temps) {
    d_.temps->read(s.t_panel, s.t_ambient, s.t_case);
    d_.temps->startConversion();
  }
  s.fan_on = fan_ctl_.update(s.t_case, now_ms);
  if (d_.fan) d_.fan->set(s.fan_on);
  agg_.addSample(s, now_ms);
  last_sample_ = s;
  have_sample_ = true;
}

void StationApp::closeWindow(uint32_t now_ms) {
  last_window_ = agg_.close(now_ms);
  have_last_window_ = true;
  if (q_count_ == kQueueSize) {  // full: drop the oldest, keep the newest
    q_head_ = (uint8_t)((q_head_ + 1) % kQueueSize);
    --q_count_;
    ++dropped_;
  }
  queue_[(q_head_ + q_count_) % kQueueSize] = last_window_;
  ++q_count_;
  flushQueue(now_ms);
}

void StationApp::flushQueue(uint32_t now_ms) {
  last_retry_ms_ = now_ms;
  if (!d_.link) { linux_ok_ = false; return; }
  if (!boot_id_[0]) {
    char id[sizeof boot_id_] = {0};
    if (!d_.link->requestBootId(id, sizeof id) || strlen(id) != 8) { linux_ok_ = false; return; }
    memcpy(boot_id_, id, sizeof boot_id_);
  }
  while (q_count_) {
    const WindowSummary& w = queue_[q_head_];
    if (!buildMeasurementJson(w, boot_id_, json_, sizeof json_)) { linux_ok_ = false; return; }
    if (!d_.link->sendMeasurement(json_)) { linux_ok_ = false; return; }  // keep it, retry later
    linux_ok_ = true;
    q_head_ = (uint8_t)((q_head_ + 1) % kQueueSize);
    --q_count_;
  }
}

void StationApp::sendConfigToLinux() {
  char buf[96];
  if (d_.link && buildMcuConfigJson(settings_, buf, sizeof buf) && d_.link->sendConfig(buf)) config_dirty_ = false;
}

void StationApp::refreshDisplay(uint32_t now_ms, bool force) {
  if (!d_.display) return;
  if (!force && (uint32_t)(now_ms - last_display_ms_) < kDisplayMs) return;
  last_display_ms_ = now_ms;
  DisplayState st;
  st.last_sample = have_sample_ ? &last_sample_ : nullptr;
  st.last_window = have_last_window_ ? &last_window_ : nullptr;
  st.open_window = &agg_.current();
  st.settings = &settings_;
  st.menu = &menu_;
  st.linux_ok = linux_ok_;
  st.pending = q_count_;
  DisplayLines lines;
  buildDisplay(st, lines);
  d_.display->show(lines);
}

}  // namespace sfs
