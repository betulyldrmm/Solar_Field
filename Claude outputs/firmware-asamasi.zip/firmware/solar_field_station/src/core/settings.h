// Values the station needs locally. The Linux database stays the source of
// truth: it sends them at start (set_config); an encoder edit is sent back
// (mcu_config). Limits are identical to backend SystemConfig.
#pragma once
#include <stdint.h>

namespace sfs {

struct StationSettings {
  static constexpr float kPanelPowerMinW = 5.0f;     // SystemConfig: gt 0
  static constexpr float kPanelPowerMaxW = 1000.0f;  // SystemConfig: le 1000
  static constexpr uint16_t kPanelCountMin = 1;
  static constexpr uint16_t kPanelCountMax = 10000;
  static constexpr uint16_t kWindowMinS = 60;        // firmware limit (needs >= 12 samples)
  static constexpr uint16_t kWindowMaxS = 3600;

  float panel_power_w = 450.0f;
  uint16_t panel_count = 8;
  uint16_t window_s = 300;
  float fan_on_c = 40.0f;
  float fan_off_c = 35.0f;

  float installedKwp() const { return panel_power_w * panel_count / 1000.0f; }
  static bool validPanelPower(float w) { return w >= kPanelPowerMinW && w <= kPanelPowerMaxW; }
  static bool validPanelCount(long n) { return n >= kPanelCountMin && n <= kPanelCountMax; }
  static bool validWindow(long s) { return s >= kWindowMinS && s <= kWindowMaxS; }
};

}  // namespace sfs
