// Builds the text of the 128x64 screen (6 lines x 21 ASCII chars) from the
// station state. Pure function -> unit-tested; the LCD driver only draws it.
#pragma once
#include <stddef.h>

#include "menu.h"
#include "ports.h"
#include "settings.h"
#include "window_aggregator.h"

namespace sfs {

struct DisplayState {
  const Sample* last_sample = nullptr;          // newest 5 s sample (may be null at start)
  const WindowSummary* last_window = nullptr;   // newest finished window (may be null)
  const WindowSummary* open_window = nullptr;   // window being filled
  const StationSettings* settings = nullptr;
  const Menu* menu = nullptr;
  bool linux_ok = false;                        // last Bridge send confirmed
  uint8_t pending = 0;                          // windows waiting to be sent
};

void buildDisplay(const DisplayState& st, DisplayLines& out);

// "12.34" style fixed-point text without float printf; "--" for invalid.
size_t formatFixed(char* buf, size_t cap, float v, uint8_t decimals);

}  // namespace sfs
