// Plain data types shared by the firmware core. No Arduino dependency:
// everything in src/core/ also compiles and is unit-tested on a PC (firmware/test).
#pragma once
#include <stdint.h>

namespace sfs {

enum class SensorState : uint8_t { Ok, NotInstalled, Disconnected, Error };

// Names match the Linux validator (backend/app/services/validator.py).
const char* sensorStateName(SensorState s);

struct Reading {
  float value = 0.0f;
  SensorState state = SensorState::NotInstalled;
  bool ok() const { return state == SensorState::Ok; }
  static Reading good(float v) { Reading r; r.value = v; r.state = SensorState::Ok; return r; }
  static Reading bad(SensorState s) { Reading r; r.state = s; return r; }
};

// One INA226: bus voltage [V] and current [A] (from the shunt voltage).
struct PowerReading {
  Reading bus_v;
  Reading current_a;
};

// Everything measured at one 5-second tick.
struct Sample {
  PowerReading ref;    // reference panel, short-circuited -> current_a = Isc (irradiance proxy)
  PowerReading batt;   // battery side -> real electrical power / energy
  Reading t_panel;
  Reading t_ambient;
  Reading t_case;
  bool fan_on = false;
};

}  // namespace sfs
