// 128x64 graphic LCD with ST7920 controller, serial mode, via the U8g2 library.
// Compiled in only when SFS_LCD_ST7920_CONFIRMED is 1 (board_config.h);
// otherwise NullDisplay is used and nothing is drawn.
// DOĞRULAMA GEREKİYOR: U8g2 software-SPI timing on the UNO Q core; 5 V module
// logic vs. the STM32's 3.3 V pins (check the module's input levels).
#pragma once
#include <Arduino.h>

#include "../config/board_config.h"
#include "../core/ports.h"

namespace sfs {

class NullDisplay : public IDisplay {
 public:
  void show(const DisplayLines&) override {}
};

#if SFS_LCD_ST7920_CONFIRMED
class St7920Display : public IDisplay {
 public:
  void begin();
  void show(const DisplayLines& d) override;
};
#endif

}  // namespace sfs
