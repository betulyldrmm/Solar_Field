#include "simple_io.h"

namespace sfs {

void GpioFan::begin() {
  if (pin_ < 0) return;
  pinMode(pin_, OUTPUT);
  set(false);
}

void GpioFan::set(bool on) {
  if (pin_ < 0) return;
  digitalWrite(pin_, (on == active_high_) ? HIGH : LOW);
}

void GpioEncoder::begin() {
  if (a_ < 0 || b_ < 0) return;
  pinMode(a_, INPUT_PULLUP);
  pinMode(b_, INPUT_PULLUP);
  if (sw_ >= 0) pinMode(sw_, INPUT_PULLUP);
  dec_.reset(digitalRead(a_) == HIGH, digitalRead(b_) == HIGH);
  ready_ = true;
}

InputEvent GpioEncoder::poll(uint32_t now_ms) {
  InputEvent ev;
  if (!ready_) return ev;
  int8_t d = dec_.update(digitalRead(a_) == HIGH, digitalRead(b_) == HIGH);
  ev.delta = reverse_ ? (int8_t)-d : d;
  if (sw_ >= 0) ev.button = button_.update(digitalRead(sw_) == LOW, now_ms);  // pull-up: pressed = LOW
  return ev;
}

}  // namespace sfs
