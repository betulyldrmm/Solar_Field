#include "ina226.h"

namespace sfs {
namespace {
constexpr uint8_t kRegConfig = 0x00, kRegShunt = 0x01, kRegBus = 0x02, kRegMfg = 0xFE, kRegDie = 0xFF;
constexpr uint16_t kMfgTi = 0x5449, kDieIna226 = 0x2260;
// AVG=16 samples, VBUSCT=VSHCT=1.1 ms, continuous shunt+bus -> one reading ≈ 35 ms of averaging.
constexpr uint16_t kConfig = 0x4000 | (0b010 << 9) | (0b100 << 6) | (0b100 << 3) | 0b111;  // 0x4527
}  // namespace

bool Ina226Monitor::writeReg(uint8_t reg, uint16_t value) {
  bus_->beginTransmission(addr_);
  bus_->write(reg);
  bus_->write((uint8_t)(value >> 8));
  bus_->write((uint8_t)(value & 0xFF));
  return bus_->endTransmission() == 0;
}

bool Ina226Monitor::readReg(uint8_t reg, uint16_t& out) {
  bus_->beginTransmission(addr_);
  bus_->write(reg);
  if (bus_->endTransmission(false) != 0) return false;
  if (bus_->requestFrom((int)addr_, 2) != 2) return false;
  const int hi = bus_->read(), lo = bus_->read();
  if (hi < 0 || lo < 0) return false;
  out = (uint16_t)((hi << 8) | lo);
  return true;
}

bool Ina226Monitor::begin() {
  present_ = false;
  if (!bus_ || addr_ == 0) return false;  // not assigned in board_config.h
  uint16_t mfg = 0, die = 0;
  if (!readReg(kRegMfg, mfg) || !readReg(kRegDie, die)) return false;
  if (mfg != kMfgTi || die != kDieIna226) return false;  // something else at this address
  present_ = writeReg(kRegConfig, kConfig);
  return present_;
}

PowerReading Ina226Monitor::read() {
  PowerReading r;
  if (!bus_ || addr_ == 0) {
    r.bus_v = r.current_a = Reading::bad(SensorState::NotInstalled);
    return r;
  }
  if (!present_ && !begin()) {  // retry detection every sample (loose connector, late power)
    r.bus_v = r.current_a = Reading::bad(SensorState::Disconnected);
    return r;
  }
  uint16_t raw_bus = 0, raw_shunt = 0;
  if (!readReg(kRegBus, raw_bus) || !readReg(kRegShunt, raw_shunt)) {
    present_ = false;
    r.bus_v = r.current_a = Reading::bad(SensorState::Error);
    return r;
  }
  r.bus_v = Reading::good(raw_bus * 1.25e-3f);
  if (shunt_ohm_ > 0.0f) {
    const float shunt_v = (int16_t)raw_shunt * 2.5e-6f;
    r.current_a = Reading::good(sign_ * shunt_v / shunt_ohm_);
  } else {
    r.current_a = Reading::bad(SensorState::Error);  // shunt value unknown: no current
  }
  return r;
}

}  // namespace sfs
