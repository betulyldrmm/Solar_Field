#include "lcd_st7920.h"

#if SFS_LCD_ST7920_CONFIRMED
#include <U8g2lib.h>

namespace sfs {
namespace {
U8G2_ST7920_128X64_F_SW_SPI u8g2(U8G2_R0, SFS_LCD_CLOCK_PIN, SFS_LCD_DATA_PIN, SFS_LCD_CS_PIN,
                                  SFS_LCD_RESET_PIN < 0 ? U8X8_PIN_NONE : SFS_LCD_RESET_PIN);
}

void St7920Display::begin() {
  u8g2.begin();
  u8g2.setFont(u8g2_font_6x10_tf);  // 21 columns x 6 lines
}

void St7920Display::show(const DisplayLines& d) {
  u8g2.clearBuffer();
  for (uint8_t i = 0; i < DisplayLines::kLines; ++i) u8g2.drawStr(0, 10 + i * 10, d.line[i]);
  u8g2.sendBuffer();
}

}  // namespace sfs
#endif
