// Fan output and rotary encoder input (plain GPIO). Unassigned pins
// (SFS_PIN_UNASSIGNED) make these do nothing instead of touching a random pin.
#pragma once
#include <Arduino.h>

#include "../core/input.h"
#include "../core/ports.h"

namespace sfs {

class GpioFan : public IFanOutput {
 public:
  GpioFan(int pin, bool active_high) : pin_(pin), active_high_(active_high) {}
  void begin();
  void set(bool on) override;

 private:
  int pin_;
  bool active_high_;
};

class GpioEncoder : public IInput {
 public:
  GpioEncoder(int pin_a, int pin_b, int pin_sw, uint8_t steps_per_detent, bool reverse)
      : a_(pin_a), b_(pin_b), sw_(pin_sw), dec_(steps_per_detent), reverse_(reverse) {}
  void begin();
  InputEvent poll(uint32_t now_ms) override;

 private:
  int a_, b_, sw_;
  QuadratureDecoder dec_;
  ButtonDebouncer button_;
  bool reverse_;
  bool ready_ = false;
};

}  // namespace sfs
