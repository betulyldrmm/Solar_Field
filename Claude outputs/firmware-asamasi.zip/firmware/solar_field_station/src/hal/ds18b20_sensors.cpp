#include "ds18b20_sensors.h"

#include <Arduino_RouterBridge.h>  // Monitor (UNO Q debug console)
#include <OneWire.h>
#include <string.h>

#include "../config/board_config.h"

namespace sfs {
namespace {
constexpr uint8_t kConvertT = 0x44, kReadScratchpad = 0xBE, kFamilyDs18b20 = 0x28;
bool unassigned(const uint8_t rom[8]) {
  for (int i = 0; i < 8; ++i) if (rom[i]) return false;
  return true;
}
}  // namespace

Ds18b20Sensors::Ds18b20Sensors(int pin, const uint8_t panel[8], const uint8_t ambient[8], const uint8_t case_t[8])
    : pin_(pin) {
  memcpy(rom_[0], panel, 8);
  memcpy(rom_[1], ambient, 8);
  memcpy(rom_[2], case_t, 8);
}

void Ds18b20Sensors::begin() {
  if (pin_ < 0 || ow_) return;
  ow_ = new OneWire((uint8_t)pin_);  // once, at start-up
#if SFS_ONEWIRE_SCAN
  printBus();
#endif
}

void Ds18b20Sensors::startConversion() {
  converting_ = false;
  if (!ow_) return;
  if (!ow_->reset()) return;  // no device answered
  ow_->skip();                // all sensors convert at once
  ow_->write(kConvertT);      // 12-bit: 750 ms; read at the next 5 s sample
  converting_ = true;
}

Reading Ds18b20Sensors::readOne(const uint8_t rom[8]) {
  if (!ow_ || unassigned(rom)) return Reading::bad(SensorState::NotInstalled);
  if (!converting_ || !ow_->reset()) return Reading::bad(SensorState::Disconnected);
  ow_->select(rom);
  ow_->write(kReadScratchpad);
  uint8_t sp[9];
  for (int i = 0; i < 9; ++i) sp[i] = ow_->read();
  if (OneWire::crc8(sp, 8) != sp[8]) return Reading::bad(SensorState::Disconnected);  // absent = all 0xFF
  const int16_t raw = (int16_t)((sp[1] << 8) | sp[0]);
  const float c = raw / 16.0f;
  // 85.0 °C straight after power-up means "no conversion done yet": not a measurement
  if (raw == 0x0550) return Reading::bad(SensorState::Error);
  return Reading::good(c);
}

void Ds18b20Sensors::read(Reading& panel, Reading& ambient, Reading& case_t) {
  panel = readOne(rom_[0]);
  ambient = readOne(rom_[1]);
  case_t = readOne(rom_[2]);
}

void Ds18b20Sensors::printBus() {
  if (!ow_) return;
  uint8_t rom[8];
  ow_->reset_search();
  while (ow_->search(rom)) {
    Monitor.print(rom[0] == kFamilyDs18b20 ? "DS18B20 ROM: {" : "1-Wire device (not DS18B20): {");
    for (int i = 0; i < 8; ++i) {
      Monitor.print("0x");
      if (rom[i] < 16) Monitor.print('0');
      Monitor.print(rom[i], HEX);
      Monitor.print(i < 7 ? ", " : "}\n");
    }
  }
}

}  // namespace sfs
