// Three DS18B20 on one 1-Wire bus, addressed by ROM code (role = panel /
// ambient / case). Uses the OneWire library (Paul Stoffregen).
// DOĞRULAMA GEREKİYOR: OneWire timing on the UNO Q (Zephyr-based core) is
// not verified yet; this class is the only place that would need changing.
#pragma once
#include <Arduino.h>

#include "../core/ports.h"

class OneWire;

namespace sfs {

class Ds18b20Sensors : public ITemperatureSensors {
 public:
  Ds18b20Sensors(int pin, const uint8_t panel[8], const uint8_t ambient[8], const uint8_t case_t[8]);
  void begin() override;
  void startConversion() override;
  void read(Reading& panel, Reading& ambient, Reading& case_t) override;
  void printBus();  // lists every ROM on the bus to Monitor (bring-up helper)

 private:
  Reading readOne(const uint8_t rom[8]);
  int pin_;
  uint8_t rom_[3][8];
  OneWire* ow_ = nullptr;
  bool converting_ = false;
};

}  // namespace sfs
