// UNO Q Bridge (Arduino_RouterBridge) between the STM32 and the Linux side.
//   measurement: Bridge.call("measurement", json).result(stored)  -> Python returns True when stored
//   mcu_config : Bridge.call("mcu_config", json).result(ok)
//   new_boot_id: Bridge.call("new_boot_id").result(id)            -> 8 hex chars from Linux
//   set_config : Bridge.provide_safe("set_config", ...)           <- Python Bridge.call
// API as in the official Arduino_RouterBridge README/examples.
// DOĞRULAMA GEREKİYOR on the real board: String arguments of this size
// (~750 bytes), call()/result() timing while Linux is still booting.
#pragma once
#include "../core/ports.h"

namespace sfs {

class StationApp;

class BridgeLink : public ILink {
 public:
  void begin(StationApp* app);
  bool requestBootId(char* out, uint8_t cap) override;
  bool sendMeasurement(const char* json) override;
  bool sendConfig(const char* json) override;
};

}  // namespace sfs
