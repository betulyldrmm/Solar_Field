// INA226 current/voltage monitor over I2C (register level, no extra library).
// Datasheet facts used: shunt voltage register 0x01 (2.5 µV/LSB, signed),
// bus voltage register 0x02 (1.25 mV/LSB), configuration 0x00,
// manufacturer ID 0xFE = 0x5449, die ID 0xFF = 0x2260.
// Current is computed from the shunt voltage and SFS_*_SHUNT_OHM, so the
// calibration register is not needed.
#pragma once
#include <Arduino.h>
#include <Wire.h>

#include "../core/ports.h"

namespace sfs {

class Ina226Monitor : public IPowerMonitor {
 public:
  Ina226Monitor(TwoWire* bus, uint8_t addr, float shunt_ohm, int8_t current_sign = 1)
      : bus_(bus), addr_(addr), shunt_ohm_(shunt_ohm), sign_(current_sign) {}
  bool begin() override;
  PowerReading read() override;

 private:
  bool readReg(uint8_t reg, uint16_t& out);
  bool writeReg(uint8_t reg, uint16_t value);
  TwoWire* bus_;
  uint8_t addr_;
  float shunt_ohm_;
  int8_t sign_;
  bool present_ = false;
};

}  // namespace sfs
