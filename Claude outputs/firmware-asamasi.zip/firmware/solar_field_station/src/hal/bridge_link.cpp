#include "bridge_link.h"

#include <Arduino.h>
#include <Arduino_RouterBridge.h>
#include <string.h>

#include "../core/station_app.h"

namespace sfs {
namespace {
StationApp* g_app = nullptr;

// Linux -> STM32. provide_safe runs it in the main loop thread, so it can
// touch StationApp without locking.
bool setConfig(String json) { return g_app ? g_app->onSetConfig(json.c_str()) : false; }
}  // namespace

void BridgeLink::begin(StationApp* app) {
  g_app = app;
  Bridge.begin();
  Bridge.provide_safe("set_config", setConfig);
}

bool BridgeLink::requestBootId(char* out, uint8_t cap) {
  String id;
  if (!Bridge.call("new_boot_id").result(id)) return false;
  if (id.length() + 1 > cap) return false;
  strncpy(out, id.c_str(), cap - 1);
  out[cap - 1] = '\0';
  return true;
}

bool BridgeLink::sendMeasurement(const char* json) {
  bool stored = false;
  if (!Bridge.call("measurement", String(json)).result(stored)) return false;  // no answer / error
  return stored;  // Python side: HardwareBridgeAdapter.on_measurement -> True when stored
}

bool BridgeLink::sendConfig(const char* json) {
  bool ok = false;
  if (!Bridge.call("mcu_config", String(json)).result(ok)) return false;
  return ok;
}

}  // namespace sfs
