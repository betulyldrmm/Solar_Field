// =====================================================================
//  ALL hardware assignments of the station live in this one file.
//
//  Nothing is assigned yet: the wiring, the INA226 addresses, the shunt
//  values and the DS18B20 ROM codes are NOT final. An unassigned part is
//  reported as NOT_INSTALLED (its fields are sent as null) — the firmware
//  never invents a value. Fill this file in when the hardware is wired,
//  following docs/firmware.md ("Donanım gelince"), and nothing else needs to change.
//
//  Sources to use (official): UNO Q pinout ABX00162-full-pinout.pdf and the
//  UNO Q user manual on docs.arduino.cc. Which TwoWire object maps to which
//  connector (A4/A5, D20/D21, Qwiic) must be checked there before choosing.
// =====================================================================
#pragma once
#include <stdint.h>

#define SFS_PIN_UNASSIGNED (-1)

// ---------------------------------------------------------------- I2C (INA226 x2)
// Pointer to the TwoWire object both INA226 are on, e.g. (&Wire) or (&Wire1).
// nullptr = not decided -> both power monitors report NOT_INSTALLED.
#define SFS_I2C_BUS nullptr
#define SFS_I2C_CLOCK_HZ 100000UL

// 7-bit addresses (0x40..0x4F, set by A0/A1 on the module). 0 = not assigned.
#define SFS_INA_REF_ADDR 0x00   // reference panel (short-circuit current)
#define SFS_INA_BATT_ADDR 0x00  // battery side

// Shunt resistance in ohm. 0 = unknown -> that monitor reports ERROR instead of a
// made-up current. (Modules marked "R100" carry 0.1 ohm — read your module first.)
#define SFS_INA_REF_SHUNT_OHM 0.0f
#define SFS_INA_BATT_SHUNT_OHM 0.0f

// Battery current sign: +1 if the INA226 reads positive while CHARGING, -1 if wired
// the other way. Decides which energy counter (in/out) a sample goes to.
#define SFS_BATT_CURRENT_SIGN (+1)

// ------------------------------------------------------------- 1-Wire (DS18B20 x3)
#define SFS_ONEWIRE_PIN SFS_PIN_UNASSIGNED
// ROM codes per role (8 bytes each, print them with SFS_ONEWIRE_SCAN = 1).
// All zero = not assigned -> that temperature reports NOT_INSTALLED.
#define SFS_DS18B20_PANEL_ROM {0, 0, 0, 0, 0, 0, 0, 0}
#define SFS_DS18B20_AMBIENT_ROM {0, 0, 0, 0, 0, 0, 0, 0}
#define SFS_DS18B20_CASE_ROM {0, 0, 0, 0, 0, 0, 0, 0}
#define SFS_ONEWIRE_SCAN 0  // 1 = print every ROM found on the bus at start (Monitor)

// ----------------------------------------------------------------- Fan (12 V, MOSFET)
#define SFS_FAN_PIN SFS_PIN_UNASSIGNED
#define SFS_FAN_ACTIVE_HIGH 1   // 1: HIGH = fan on (N-channel low-side switch)

// ------------------------------------------------------------- Rotary encoder + button
#define SFS_ENC_A_PIN SFS_PIN_UNASSIGNED
#define SFS_ENC_B_PIN SFS_PIN_UNASSIGNED
#define SFS_ENC_SW_PIN SFS_PIN_UNASSIGNED
#define SFS_ENC_STEPS_PER_DETENT 4  // typical EC11; check by turning one click
#define SFS_ENC_REVERSE 0           // 1 if clockwise counts down

// -------------------------------------------------------- 12864 LCD (ST7920 controller)
// Enable only after the module's controller is confirmed as ST7920 and the pins
// are wired. Serial mode: E = clock, R/W = data, RS = chip select, PSB tied low.
#ifndef SFS_LCD_ST7920_CONFIRMED
#define SFS_LCD_ST7920_CONFIRMED 0
#endif
#define SFS_LCD_CLOCK_PIN SFS_PIN_UNASSIGNED  // E
#define SFS_LCD_DATA_PIN SFS_PIN_UNASSIGNED   // R/W
#define SFS_LCD_CS_PIN SFS_PIN_UNASSIGNED     // RS
#define SFS_LCD_RESET_PIN SFS_PIN_UNASSIGNED  // optional
