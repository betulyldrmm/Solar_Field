// Solar Field Station — STM32U585 side of the Arduino UNO Q.
//
//   every 5 s : INA226 x2 + DS18B20 x3 -> fan control -> 5-minute window statistics
//   every 5 min: window summary (schema v2 JSON) -> Bridge -> Linux (SQLite + CSV)
//   encoder   : panel power / panel count  -> Linux (mcu_config)
//   LCD       : ST7920 12864, only when confirmed in board_config.h
//
// All pins, buses and addresses: src/config/board_config.h (nothing assigned yet).
// All logic: src/core (unit-tested on a PC, see firmware/test).
// Hardware access: src/hal.
//
// Libraries: Arduino_RouterBridge (UNO Q), OneWire (Paul Stoffregen),
//            U8g2 (only if SFS_LCD_ST7920_CONFIRMED = 1).
// Status: NOT YET COMPILED FOR / RUN ON A REAL UNO Q — see docs/firmware.md.

#include <Arduino.h>
#include <Arduino_RouterBridge.h>
#include <Wire.h>

#include "src/config/board_config.h"
#include "src/core/station_app.h"
#include "src/hal/bridge_link.h"
#include "src/hal/ds18b20_sensors.h"
#include "src/hal/ina226.h"
#include "src/hal/lcd_st7920.h"
#include "src/hal/simple_io.h"

namespace {

const uint8_t kRomPanel[8] = SFS_DS18B20_PANEL_ROM;
const uint8_t kRomAmbient[8] = SFS_DS18B20_AMBIENT_ROM;
const uint8_t kRomCase[8] = SFS_DS18B20_CASE_ROM;

sfs::Ina226Monitor ref_monitor(SFS_I2C_BUS, SFS_INA_REF_ADDR, SFS_INA_REF_SHUNT_OHM, 1);
sfs::Ina226Monitor batt_monitor(SFS_I2C_BUS, SFS_INA_BATT_ADDR, SFS_INA_BATT_SHUNT_OHM, SFS_BATT_CURRENT_SIGN);
sfs::Ds18b20Sensors temps(SFS_ONEWIRE_PIN, kRomPanel, kRomAmbient, kRomCase);
sfs::GpioFan fan(SFS_FAN_PIN, SFS_FAN_ACTIVE_HIGH);
sfs::GpioEncoder encoder(SFS_ENC_A_PIN, SFS_ENC_B_PIN, SFS_ENC_SW_PIN, SFS_ENC_STEPS_PER_DETENT, SFS_ENC_REVERSE);
#if SFS_LCD_ST7920_CONFIRMED
sfs::St7920Display display;
#else
sfs::NullDisplay display;
#endif
sfs::BridgeLink link;

sfs::StationApp app({&ref_monitor, &batt_monitor, &temps, &fan, &encoder, &display, &link});

}  // namespace

void setup() {
  Monitor.begin();
  TwoWire* bus = SFS_I2C_BUS;
  if (bus) {
    bus->begin();
    bus->setClock(SFS_I2C_CLOCK_HZ);
  }
  fan.begin();
  encoder.begin();
#if SFS_LCD_ST7920_CONFIRMED
  display.begin();
#endif
  link.begin(&app);  // Bridge.begin() + set_config handler
  app.begin(millis());
  Monitor.println("Solar Field Station firmware started (see board_config.h for unassigned hardware)");
}

void loop() {
  app.loop(millis());
}
