// Tiny test framework (no external dependency).
#pragma once
#include <math.h>
#include <stdio.h>

namespace minitest {
struct Test { const char* name; void (*fn)(); Test* next; };
inline Test*& head() { static Test* h = nullptr; return h; }
inline int& failures() { static int f = 0; return f; }
inline int& checks() { static int c = 0; return c; }
struct Reg { Reg(Test* t) { t->next = head(); head() = t; } };
}  // namespace minitest

#define TEST(name)                                                        \
  static void name();                                                     \
  static minitest::Test name##_t = {#name, name, nullptr};                \
  static minitest::Reg name##_r(&name##_t);                               \
  static void name()

#define CHECK(cond)                                                                  \
  do {                                                                               \
    ++minitest::checks();                                                            \
    if (!(cond)) { ++minitest::failures(); printf("  FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond); } \
  } while (0)

#define CHECK_NEAR(a, b, tol)                                                        \
  do {                                                                               \
    ++minitest::checks();                                                            \
    double _a = (a), _b = (b);                                                       \
    if (!(fabs(_a - _b) <= (tol))) { ++minitest::failures();                         \
      printf("  FAIL %s:%d  %s=%g vs %s=%g\n", __FILE__, __LINE__, #a, _a, #b, _b); } \
  } while (0)
