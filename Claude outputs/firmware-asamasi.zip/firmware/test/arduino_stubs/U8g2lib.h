#pragma once
#include "Arduino.h"
#define U8X8_PIN_NONE 255
struct u8g2_cb_t {};
extern const u8g2_cb_t* U8G2_R0;
extern const uint8_t u8g2_font_6x10_tf[];
class U8G2_ST7920_128X64_F_SW_SPI {
 public:
  U8G2_ST7920_128X64_F_SW_SPI(const u8g2_cb_t*, int, int, int, int) {}
  void begin() {}
  void setFont(const uint8_t*) {}
  void clearBuffer() {}
  void drawStr(int, int, const char*) {}
  void sendBuffer() {}
};
