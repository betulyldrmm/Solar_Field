// COMPILE-CHECK STUBS ONLY: just enough of the Arduino API for `make hal-syntax`
// to catch typos in src/hal. Says nothing about behaviour on the real UNO Q.
#pragma once
#include <stdint.h>
#include <string.h>
#include <string>
#define HIGH 1
#define LOW 0
#define INPUT 0
#define OUTPUT 1
#define INPUT_PULLUP 2
#define HEX 16
inline void pinMode(int, int) {}
inline void digitalWrite(int, int) {}
inline int digitalRead(int) { return HIGH; }
inline unsigned long millis() { return 0; }
class String {
 public:
  String() {}
  String(const char* s) : s_(s) {}
  const char* c_str() const { return s_.c_str(); }
  unsigned int length() const { return (unsigned int)s_.size(); }
 private:
  std::string s_;
};
struct Print {
  void begin() {}
  template <class T> void print(T) {}
  template <class T> void print(T, int) {}
  template <class T> void println(T) {}
};
extern Print Serial;
