#include "Arduino.h"
#include "Arduino_RouterBridge.h"
#include "U8g2lib.h"
#include "Wire.h"
Print Serial, Monitor;
TwoWire Wire;
BridgeClass Bridge;
const u8g2_cb_t* U8G2_R0 = nullptr;
const uint8_t u8g2_font_6x10_tf[1] = {0};
