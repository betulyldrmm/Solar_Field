#pragma once
#include "Arduino.h"
struct RpcCall {
  template <class T> bool result(T&) { return true; }
};
struct BridgeClass {
  bool begin() { return true; }
  template <class F> bool provide(const char*, F) { return true; }
  template <class F> bool provide_safe(const char*, F) { return true; }
  template <class... A> RpcCall call(const char*, A...) { return RpcCall(); }
  template <class... A> void notify(const char*, A...) {}
};
extern BridgeClass Bridge;
extern Print Monitor;
