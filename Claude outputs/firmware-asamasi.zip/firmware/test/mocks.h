// Fake hardware for the host tests.
#pragma once
#include <string.h>

#include <string>
#include <vector>

#include "core/ports.h"

namespace mock {
using namespace sfs;

struct PowerMonitor : IPowerMonitor {
  PowerReading next;
  int begins = 0;
  bool begin() override { ++begins; return true; }
  PowerReading read() override { return next; }
  void set(float v, float i) { next.bus_v = Reading::good(v); next.current_a = Reading::good(i); }
  void fail(SensorState s) { next.bus_v = next.current_a = Reading::bad(s); }
};

struct Temps : ITemperatureSensors {
  Reading panel = Reading::good(25), ambient = Reading::good(15), case_t = Reading::good(22);
  int conversions = 0;
  void begin() override {}
  void startConversion() override { ++conversions; }
  void read(Reading& p, Reading& a, Reading& c) override { p = panel; a = ambient; c = case_t; }
};

struct Fan : IFanOutput {
  bool on = false;
  int writes = 0;
  void set(bool v) override { on = v; ++writes; }
};

struct Input : IInput {
  std::vector<InputEvent> queue;
  InputEvent poll(uint32_t) override {
    if (queue.empty()) return InputEvent();
    InputEvent e = queue.front();
    queue.erase(queue.begin());
    return e;
  }
  void turn(int8_t d) { InputEvent e; e.delta = d; queue.push_back(e); }
  void click() { InputEvent e; e.button = ButtonEvent::Click; queue.push_back(e); }
  void longPress() { InputEvent e; e.button = ButtonEvent::LongPress; queue.push_back(e); }
};

struct Display : IDisplay {
  DisplayLines last;
  int shows = 0;
  void show(const DisplayLines& d) override { last = d; ++shows; }
};

struct Link : ILink {
  bool linux_up = true;
  bool give_boot_id = true;
  int boot_id_requests = 0;
  std::vector<std::string> measurements, configs;
  bool requestBootId(char* out, uint8_t cap) override {
    ++boot_id_requests;
    if (!linux_up || !give_boot_id) return false;
    strncpy(out, "a1b2c3d4", cap - 1);
    out[cap - 1] = '\0';
    return true;
  }
  bool sendMeasurement(const char* json) override {
    if (!linux_up) return false;
    measurements.push_back(json);
    return true;
  }
  bool sendConfig(const char* json) override {
    if (!linux_up) return false;
    configs.push_back(json);
    return true;
  }
};

}  // namespace mock
