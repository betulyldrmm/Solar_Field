// Host unit tests for src/core. Run: make   (see Makefile)
#include <stdio.h>
#include <string.h>

#include <string>

#include "core/display_model.h"
#include "core/fan_controller.h"
#include "core/input.h"
#include "core/json_util.h"
#include "core/menu.h"
#include "core/messages.h"
#include "core/station_app.h"
#include "core/window_aggregator.h"
#include "minitest.h"
#include "mocks.h"

using namespace sfs;

static bool contains(const std::string& s, const char* part) { return s.find(part) != std::string::npos; }

// ============================================================== JSON
TEST(json_numbers_are_fixed_point_and_never_nan) {
  char b[128];
  JsonWriter j(b, sizeof b);
  j.beginObject().key("a").num(1.23456, 3).key("b").num(-0.0004, 3).key("c").num(-2.5, 1)
      .key("d").num(NAN, 2).key("e").integer(-42).key("f").num(11.9995, 3).endObject();
  CHECK(j.ok());
  CHECK(std::string(b) == "{\"a\":1.235,\"b\":0.000,\"c\":-2.5,\"d\":null,\"e\":-42,\"f\":12.000}");
}

TEST(json_escapes_and_detects_overflow) {
  char b[64];
  JsonWriter j(b, sizeof b);
  j.beginObject().key("s").str("a\"b\\c\n").endObject();
  CHECK(std::string(b) == "{\"s\":\"a\\\"b\\\\c\"}");
  char small[8];
  JsonWriter k(small, sizeof small);
  k.beginObject().key("long_key").integer(1).endObject();
  CHECK(!k.ok());
  CHECK(strlen(small) < sizeof small);
}

TEST(json_find_number) {
  double v = 0;
  const char* js = "{\"schema_version\": 1, \"panel_power_w\":455.5,\"panel_count\" : 12, \"x\":\"y\"}";
  CHECK(jsonFindNumber(js, "panel_power_w", &v) && v == 455.5);
  CHECK(jsonFindNumber(js, "panel_count", &v) && v == 12);
  CHECK(!jsonFindNumber(js, "missing", &v));
  CHECK(!jsonFindNumber(js, "x", &v));  // a string is not a number
}

// ======================================================== aggregator
static Sample sample(float isc, float bv, float bi, float tc = 22.0f, bool fan = false) {
  Sample s;
  s.ref.bus_v = Reading::good(0.02f);
  s.ref.current_a = Reading::good(isc);
  s.batt.bus_v = Reading::good(bv);
  s.batt.current_a = Reading::good(bi);
  s.t_panel = Reading::good(25.0f);
  s.t_ambient = Reading::good(15.0f);
  s.t_case = Reading::good(tc);
  s.fan_on = fan;
  return s;
}

TEST(window_mean_min_max_energy_completeness) {
  WindowAggregator a;
  a.configure(300000, 5000);
  a.begin(0);
  for (int k = 1; k <= 60; ++k) a.addSample(sample(0.060f + 0.001f * (k % 10), 12.0f, 0.5f), k * 5000u);
  CHECK(a.windowDue(300000));
  WindowSummary w = a.close(300000);
  CHECK(w.sequence == 1 && w.samples_expected == 60 && w.samples_taken == 60);
  CHECK_NEAR(w.completeness, 1.0, 1e-6);
  CHECK_NEAR(w.ref_i.min, 0.060, 1e-6);
  CHECK_NEAR(w.ref_i.max, 0.069, 1e-6);
  CHECK_NEAR(w.ref_i.mean(), 0.0645, 1e-4);
  // 12 V * 0.5 A = 6 W for 300 s = 0.5 Wh charged, nothing discharged
  CHECK_NEAR(w.batt_energy_in_wh, 0.5, 1e-6);
  CHECK_NEAR(w.batt_energy_out_wh, 0.0, 1e-9);
  CHECK_NEAR(w.window_s, 300.0, 1e-6);
  CHECK(a.current().sequence == 2);  // next window started
}

TEST(window_discharge_goes_to_out_counter) {
  WindowAggregator a;
  a.configure(60000, 5000);
  a.begin(0);
  for (int k = 1; k <= 12; ++k) a.addSample(sample(0.05f, 11.0f, -0.3f), k * 5000u);
  WindowSummary w = a.close(60000);
  CHECK_NEAR(w.batt_energy_out_wh, 11.0 * 0.3 * 60 / 3600.0, 1e-6);
  CHECK_NEAR(w.batt_energy_in_wh, 0.0, 1e-9);
}

TEST(window_gaps_are_not_counted_as_energy) {
  WindowAggregator a;
  a.configure(300000, 5000);
  a.begin(0);
  a.addSample(sample(0.05f, 12.0f, 1.0f), 5000);
  a.addSample(sample(0.05f, 12.0f, 1.0f), 200000);  // 195 s stall: counts as one 5 s sample
  WindowSummary w = a.close(300000);
  CHECK_NEAR(w.batt_energy_in_wh, 2 * 12.0 * 5 / 3600.0, 1e-6);
  CHECK_NEAR(w.completeness, 2.0 / 60.0, 1e-6);
}

TEST(window_failed_sensor_reports_state_and_keeps_others) {
  WindowAggregator a;
  a.configure(300000, 5000);
  a.begin(0);
  for (int k = 1; k <= 60; ++k) {
    Sample s = sample(0.05f, 12.0f, 0.2f);
    s.t_case = Reading::bad(SensorState::Disconnected);
    if (k > 30) s.ref.current_a = Reading::bad(SensorState::Error);  // half the window lost
    a.addSample(s, k * 5000u);
  }
  WindowSummary w = a.close(300000);
  CHECK(w.t_case.n == 0 && w.t_case.state() == SensorState::Disconnected);
  CHECK(w.t_panel.state() == SensorState::Ok);
  CHECK_NEAR(w.completeness, 0.5, 1e-6);
  CHECK(w.ref_p.n == 30);  // reference V*I only where both were valid
}

TEST(window_survives_millis_wraparound) {
  WindowAggregator a;
  a.configure(60000, 5000);
  const uint32_t start = 0xFFFFFFFFu - 20000u;
  a.begin(start);
  for (int k = 1; k <= 12; ++k) a.addSample(sample(0.05f, 12.0f, 1.0f), start + k * 5000u);
  CHECK(a.windowDue(start + 60000u));
  WindowSummary w = a.close(start + 60000u);
  CHECK(w.samples_taken == 12);
  CHECK_NEAR(w.window_s, 60.0, 1e-6);
  CHECK_NEAR(w.batt_energy_in_wh, 12.0 * 60 / 3600.0, 1e-6);
}

TEST(window_fan_run_time) {
  WindowAggregator a;
  a.configure(60000, 5000);
  a.begin(0);
  for (int k = 1; k <= 12; ++k) a.addSample(sample(0.05f, 12, 0, 30, k > 6), k * 5000u);
  WindowSummary w = a.close(60000);
  CHECK_NEAR(w.fan_on_s, 30.0, 1e-6);
  CHECK(w.fan_on_at_end);
}

// ================================================================ fan
TEST(fan_hysteresis_and_min_switch_time) {
  FanController f;
  CHECK(!f.update(Reading::good(30), 0));
  CHECK(f.update(Reading::good(40.5f), 1000));            // on at >= 40
  CHECK(f.update(Reading::good(37), 2000));               // between: stays on
  CHECK(f.update(Reading::good(34), 10000));              // below off, but < 30 s since switch-on
  CHECK(!f.update(Reading::good(34), 32000));             // now off
  CHECK(f.reason() == FanReason::Off);
}

TEST(fan_failsafe_on_lost_case_sensor) {
  FanController f;
  f.update(Reading::good(25), 0);
  CHECK(!f.update(Reading::bad(SensorState::Disconnected), 5000));   // one glitch: keep state
  CHECK(!f.update(Reading::bad(SensorState::Disconnected), 10000));
  CHECK(f.update(Reading::bad(SensorState::Disconnected), 15000));   // 3rd in a row: ON
  CHECK(f.reason() == FanReason::SensorFailsafe);
  CHECK(f.update(Reading::good(37), 20000));                         // back, between thresholds: keep running
  CHECK(!f.update(Reading::good(30), 60000));                        // cooled down: off
}

TEST(fan_emergency_and_threshold_validation) {
  FanController f;
  CHECK(f.update(Reading::good(75), 0));
  CHECK(f.reason() == FanReason::Emergency);
  CHECK(!f.setThresholds(40, 39));   // needs >= 2 °C hysteresis
  CHECK(f.setThresholds(45, 40));
  CHECK(f.config().on_c == 45);
}

// ============================================================== input
TEST(quadrature_counts_detents_and_ignores_bounce) {
  QuadratureDecoder q(4);
  q.reset(true, true);
  // Gray sequence 11 -> 01 -> 00 -> 10 -> 11 = +1 detent (direction flip: SFS_ENC_REVERSE)
  int total = q.update(false, true) + q.update(false, false) + q.update(true, false) + q.update(true, true);
  CHECK(total == 1);
  total = q.update(true, false) + q.update(false, false) + q.update(false, true) + q.update(true, true);
  CHECK(total == -1);
  total = q.update(true, false) + q.update(true, true) + q.update(true, false) + q.update(true, true);  // bounce
  CHECK(total == 0);
  total = q.update(false, false);  // impossible jump 11 -> 00
  CHECK(total == 0);
}

TEST(button_click_long_press_and_debounce) {
  ButtonDebouncer b(30, 800);
  CHECK(b.update(true, 0) == ButtonEvent::None);
  CHECK(b.update(false, 10) == ButtonEvent::None);  // 10 ms spike: ignored
  CHECK(b.update(false, 100) == ButtonEvent::None);
  b.update(true, 200);
  b.update(true, 240);                               // stable press
  CHECK(b.update(false, 400) == ButtonEvent::None);
  CHECK(b.update(false, 440) == ButtonEvent::Click);
  b.update(true, 1000);
  b.update(true, 1040);
  CHECK(b.update(true, 1900) == ButtonEvent::LongPress);
  b.update(false, 2000);
  CHECK(b.update(false, 2040) == ButtonEvent::None);  // no click after a long press
}

// =============================================================== menu
static InputEvent turn(int8_t d) { InputEvent e; e.delta = d; return e; }
static InputEvent click() { InputEvent e; e.button = ButtonEvent::Click; return e; }

TEST(menu_edit_and_commit) {
  Menu m;
  StationSettings s;
  m.handle(turn(1), s, 0);
  CHECK(m.page() == 1);
  CHECK(!m.handle(click(), s, 1000));
  CHECK(m.state() == MenuState::EditPower);
  m.handle(turn(2), s, 2000);                // +10 W (slow turns)
  m.handle(turn(1), s, 3000);
  CHECK_NEAR(m.draftPower(), 465.0, 1e-6);
  CHECK(s.panel_power_w == 450.0f);          // not applied yet
  m.handle(click(), s, 4000);
  m.handle(turn(4), s, 5000);
  CHECK(m.draftCount() == 12);
  CHECK(m.handle(click(), s, 6000));         // commit
  CHECK(s.panel_power_w == 465.0f && s.panel_count == 12 && m.state() == MenuState::Home);
}

TEST(menu_limits_cancel_and_timeout) {
  Menu m;
  StationSettings s;
  m.handle(click(), s, 0);
  for (int i = 0; i < 300; ++i) m.handle(turn(-1), s, 1000 + i * 1000u);
  CHECK(m.draftPower() == StationSettings::kPanelPowerMinW);
  InputEvent lp; lp.button = ButtonEvent::LongPress;
  m.handle(lp, s, 400000);
  CHECK(m.state() == MenuState::Home && s.panel_power_w == 450.0f);  // cancelled
  m.handle(click(), s, 500000);
  m.tick(500000 + Menu::kEditTimeoutMs);
  CHECK(m.state() == MenuState::Home);
  m.handle(click(), s, 600000);
  m.handle(turn(1), s, 600010);
  m.handle(turn(1), s, 600020);  // fast turn -> x10
  CHECK_NEAR(m.draftPower(), 450 + 5 + 50, 1e-6);
}

// ========================================================== set_config
TEST(set_config_applies_valid_fields_only) {
  StationSettings s;
  CHECK(applySetConfig("{\"schema_version\":1,\"panel_power_w\":500,\"panel_count\":0,"
                       "\"measurement_interval_s\":600,\"fan_on_c\":45,\"fan_off_c\":44}", s) == ConfigResult::Applied);
  CHECK(s.panel_power_w == 500.0f);
  CHECK(s.panel_count == 8);          // 0 is out of range -> ignored
  CHECK(s.window_s == 600);
  CHECK(s.fan_on_c == 40.0f);         // 45/44: less than 2 °C hysteresis -> pair ignored
  CHECK(applySetConfig("{\"schema_version\":2,\"panel_power_w\":300}", s) == ConfigResult::Rejected);
  CHECK(s.panel_power_w == 500.0f);
  CHECK(applySetConfig("garbage", s) == ConfigResult::Rejected);
}

// ============================================================ messages
TEST(measurement_json_contains_schema_v2_fields) {
  WindowAggregator a;
  a.configure(300000, 5000);
  a.begin(0);
  for (int k = 1; k <= 60; ++k) a.addSample(sample(0.07f, 11.8f, 0.3f), k * 5000u);
  WindowSummary w = a.close(300000);
  char buf[kMeasurementJsonMax];
  size_t n = buildMeasurementJson(w, "a1b2c3d4", buf, sizeof buf);
  std::string js(buf);
  CHECK(n > 0 && n < kMeasurementJsonMax);
  CHECK(contains(js, "\"schema_version\":2") && contains(js, "\"boot_id\":\"a1b2c3d4\""));
  CHECK(contains(js, "\"window_s\":300.0") && contains(js, "\"samples_expected\":60"));
  CHECK(contains(js, "\"current_a\":0.070000") && contains(js, "\"data_completeness\":1.000"));
  CHECK(contains(js, "\"battery_energy_in_wh\":0.29500"));
  CHECK(contains(js, "\"stats\":{\"voltage_v\":{\"min\":0.0200,\"max\":0.0200,\"n\":60}"));
  CHECK(contains(js, "\"sensor_status\":\"OK\""));
}

TEST(measurement_json_nulls_for_missing_sensors) {
  WindowAggregator a;
  a.configure(60000, 5000);
  a.begin(0);
  for (int k = 1; k <= 12; ++k) {
    Sample s = sample(0.07f, 11.8f, 0.3f);
    s.batt.bus_v = s.batt.current_a = Reading::bad(SensorState::NotInstalled);
    s.t_ambient = Reading::bad(SensorState::Disconnected);
    a.addSample(s, k * 5000u);
  }
  char buf[kMeasurementJsonMax];
  buildMeasurementJson(a.close(60000), "a1b2c3d4", buf, sizeof buf);
  std::string js(buf);
  CHECK(contains(js, "\"battery_voltage_v\":null") && contains(js, "\"battery_energy_in_wh\":null"));
  CHECK(contains(js, "\"ambient_temperature_c\":null"));
  CHECK(contains(js, "\"ina_batt\":\"NOT_INSTALLED\"") && contains(js, "\"t_ambient\":\"DISCONNECTED\""));
  CHECK(contains(js, "\"sensor_status\":\"DEGRADED\""));
}

TEST(mcu_config_json) {
  StationSettings s;
  s.panel_power_w = 455;
  s.panel_count = 12;
  char buf[96];
  buildMcuConfigJson(s, buf, sizeof buf);
  CHECK(std::string(buf) == "{\"schema_version\":1,\"panel_power_w\":455.0,\"panel_count\":12}");
}

// ============================================================= display
static void checkWidth(const DisplayLines& d) {
  for (int i = 0; i < DisplayLines::kLines; ++i) CHECK(strlen(d.line[i]) <= DisplayLines::kCols);
}

TEST(display_pages_fit_the_screen) {
  StationSettings s;
  s.panel_count = 10000;
  Menu m;
  Sample x = sample(0.0712f, 11.82f, -1.25f, 22.8f, true);
  WindowAggregator a;
  a.configure(300000, 5000);
  a.begin(0);
  a.addSample(x, 5000);
  WindowSummary w = a.close(300000);
  DisplayState st;
  st.last_sample = &x;
  st.last_window = &w;
  st.open_window = &a.current();
  st.settings = &s;
  st.menu = &m;
  DisplayLines d;
  for (int page = 0; page < Menu::kHomePages; ++page) {
    buildDisplay(st, d);
    checkWidth(d);
    m.handle(turn(1), s, 1000 + page * 1000u);
  }
  buildDisplay(st, d);
  CHECK(std::string(d.line[1]) == "Isc  71.2 mA");
  CHECK(contains(d.line[3], "Fan ACIK"));
  m.handle(click(), s, 9000);
  buildDisplay(st, d);
  CHECK(std::string(d.line[0]) == "AYAR 1/2");
  checkWidth(d);
}

TEST(format_fixed) {
  char b[16];
  formatFixed(b, sizeof b, -0.004f, 2);
  CHECK(std::string(b) == "0.00");
  formatFixed(b, sizeof b, 11.825f, 2);
  CHECK(std::string(b) == "11.83" || std::string(b) == "11.82");  // float rounding
  formatFixed(b, sizeof b, NAN, 1);
  CHECK(std::string(b) == "--");
}

// ========================================================= StationApp
struct Rig {
  mock::PowerMonitor ref, batt;
  mock::Temps temps;
  mock::Fan fan;
  mock::Input input;
  mock::Display display;
  mock::Link link;
  StationApp app{StationDeps{&ref, &batt, &temps, &fan, &input, &display, &link}};
  uint32_t now = 0;
  Rig() { ref.set(0.02f, 0.071f); batt.set(11.8f, 0.4f); app.begin(now); }
  void run(uint32_t ms) { for (uint32_t end = now + ms; now < end; now += 100) app.loop(now); }
};

TEST(app_sends_one_window_every_5_minutes) {
  Rig r;
  r.run(10 * 60 * 1000 + 2000);
  CHECK(r.link.measurements.size() == 2);
  CHECK(r.link.boot_id_requests == 1);
  CHECK(contains(r.link.measurements[0], "\"sequence\":1") && contains(r.link.measurements[1], "\"sequence\":2"));
  CHECK(contains(r.link.measurements[0], "\"boot_id\":\"a1b2c3d4\""));
  CHECK(r.app.pending() == 0);
  CHECK(r.temps.conversions > 100);
}

TEST(app_keeps_measuring_while_linux_is_down_then_delivers_in_order) {
  Rig r;
  r.link.linux_up = false;
  r.run(16 * 60 * 1000);        // 3 windows while Linux boots
  CHECK(r.link.measurements.empty() && r.app.pending() == 3);
  r.link.linux_up = true;
  r.run(15 * 1000);             // next retry
  CHECK(r.link.measurements.size() == 3 && r.app.pending() == 0);
  CHECK(contains(r.link.measurements[0], "\"sequence\":1") && contains(r.link.measurements[2], "\"sequence\":3"));
}

TEST(app_queue_full_drops_oldest_window) {
  Rig r;
  r.link.linux_up = false;
  r.run((StationApp::kQueueSize + 2) * 5 * 60 * 1000 + 3000);
  CHECK(r.app.pending() == StationApp::kQueueSize && r.app.droppedWindows() == 2);
  r.link.linux_up = true;
  r.run(15 * 1000);
  CHECK(contains(r.link.measurements.front(), "\"sequence\":3"));  // 1 and 2 were dropped
}

TEST(app_waits_for_boot_id_before_sending) {
  Rig r;
  r.link.give_boot_id = false;
  r.run(6 * 60 * 1000);
  CHECK(r.link.measurements.empty() && r.app.pending() == 1 && r.app.bootId()[0] == '\0');
  r.link.give_boot_id = true;
  r.run(15 * 1000);
  CHECK(r.link.measurements.size() == 1 && std::string(r.app.bootId()) == "a1b2c3d4");
}

TEST(app_encoder_edit_is_sent_to_linux) {
  Rig r;
  r.input.click();
  r.input.turn(1);
  r.input.click();
  r.input.turn(2);
  r.input.click();
  r.run(2000);
  CHECK(r.app.settings().panel_power_w == 455.0f && r.app.settings().panel_count == 10);
  CHECK(r.link.configs.size() == 1 && contains(r.link.configs[0], "\"panel_count\":10"));
}

TEST(app_set_config_changes_window_and_fan) {
  Rig r;
  CHECK(r.app.onSetConfig("{\"schema_version\":1,\"measurement_interval_s\":60,\"fan_on_c\":30,\"fan_off_c\":25}"));
  CHECK(!r.app.onSetConfig("{\"schema_version\":7}"));
  r.temps.case_t = Reading::good(31);
  r.run(2 * 60 * 1000 + 2000);
  CHECK(r.link.measurements.size() == 2);            // 60 s windows now
  CHECK(contains(r.link.measurements[0], "\"window_s\":60.0"));
  CHECK(r.fan.on && r.app.fanReason() == FanReason::Hysteresis);
}

TEST(app_fan_failsafe_drives_output) {
  Rig r;
  r.temps.case_t = Reading::bad(SensorState::Disconnected);
  r.run(20 * 1000);
  CHECK(r.fan.on && r.app.fanReason() == FanReason::SensorFailsafe);
}

TEST(app_unassigned_hardware_gives_nulls_not_values) {
  Rig r;
  r.ref.fail(SensorState::NotInstalled);
  r.batt.fail(SensorState::NotInstalled);
  r.temps.panel = r.temps.ambient = r.temps.case_t = Reading::bad(SensorState::NotInstalled);
  r.run(5 * 60 * 1000 + 2000);
  CHECK(r.link.measurements.size() == 1);
  const std::string& js = r.link.measurements[0];
  CHECK(contains(js, "\"current_a\":null") && contains(js, "\"data_completeness\":0.000"));
  CHECK(contains(js, "\"ina_ref\":\"NOT_INSTALLED\""));
}

// ============================================== messages for Python check
static void emitJson(const char* path) {
  FILE* f = fopen(path, "w");
  if (!f) { printf("cannot write %s\n", path); return; }
  char buf[kMeasurementJsonMax];
  // 1) normal window, 2) partial window with a failed sensor, 3) nothing installed
  for (int variant = 0; variant < 3; ++variant) {
    WindowAggregator a;
    a.configure(300000, 5000);
    a.begin(0);
    for (int k = 1; k <= 60; ++k) {
      Sample s = sample(0.060f + 0.0005f * (k % 20), 11.7f + 0.002f * k, k < 40 ? 0.45f : -0.2f, 22 + k * 0.1f, k > 50);
      if (variant == 1) { if (k > 45) s.ref.current_a = Reading::bad(SensorState::Error); s.t_ambient = Reading::bad(SensorState::Disconnected); }
      if (variant == 2) s = Sample();
      a.addSample(s, k * 5000u);
    }
    WindowSummary w = a.close(300000);
    buildMeasurementJson(w, "a1b2c3d4", buf, sizeof buf);
    fprintf(f, "%s\n", buf);
  }
  StationSettings s;
  s.panel_power_w = 455;
  s.panel_count = 12;
  buildMcuConfigJson(s, buf, sizeof buf);
  fprintf(f, "%s\n", buf);
  fclose(f);
  printf("wrote %s\n", path);
}

int main(int argc, char** argv) {
  int n = 0;
  for (minitest::Test* t = minitest::head(); t; t = t->next) {
    const int before = minitest::failures();
    t->fn();
    printf("%s %s\n", minitest::failures() == before ? "ok  " : "FAIL", t->name);
    ++n;
  }
  printf("\n%d tests, %d checks, %d failures\n", n, minitest::checks(), minitest::failures());
  if (argc == 3 && strcmp(argv[1], "--emit-json") == 0) emitJson(argv[2]);
  return minitest::failures() ? 1 : 0;
}
