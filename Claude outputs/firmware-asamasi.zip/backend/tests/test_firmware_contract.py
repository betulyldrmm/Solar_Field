"""Contract test: the JSON the C++ firmware core produces must pass the Python
validator unchanged. Builds and runs firmware/test (host build, no hardware);
skipped when no C++ compiler is available (e.g. on Windows without g++)."""

import json
import shutil
import subprocess
from datetime import UTC, datetime
from pathlib import Path

import pytest

from app.models.schemas import SystemConfig
from app.services.validator import validate_message

FW_TEST = Path(__file__).resolve().parents[2] / "firmware" / "test"
NOW = datetime(2026, 11, 28, 10, 0, tzinfo=UTC)

pytestmark = pytest.mark.skipif(
    not (shutil.which("make") and (shutil.which("g++") or shutil.which("c++")) and FW_TEST.exists()),
    reason="C++ toolchain or firmware/test not available",
)


@pytest.fixture(scope="module")
def messages():
    r = subprocess.run(["make", "-s", "json"], cwd=FW_TEST, capture_output=True, text=True, timeout=300)
    assert r.returncode == 0, r.stdout + r.stderr  # also fails if any C++ unit test fails
    lines = (FW_TEST / "build" / "bridge_messages.jsonl").read_text().splitlines()
    return [json.loads(x) for x in lines]


def test_normal_window_passes_validator_without_issues(messages):
    res = validate_message(messages[0], received_at=NOW, data_source="hardware")
    m = res.measurement
    assert res.issues == []
    assert m.schema_version == 2 and m.window_s == 300 and m.samples_expected == 60
    assert m.data_completeness == 1.0
    st = m.stats["current_a"]
    assert st["n"] == 60 and st["min"] <= m.current_a <= st["max"]
    assert m.battery_energy_in_wh > 0 and m.battery_energy_out_wh > 0   # charged, then discharged
    assert 0 < m.fan_on_s <= 300


def test_partial_window_with_failed_sensor(messages):
    res = validate_message(messages[1], received_at=NOW, data_source="hardware")
    m = res.measurement
    assert m.ambient_temperature_c is None and m.sensor_states["t_ambient"] == "DISCONNECTED"
    assert m.data_completeness == pytest.approx(45 / 60, abs=1e-3)
    assert "window_incomplete" in m.quality_flags
    assert [i.sensor for i in res.issues] == ["t_ambient"]


def test_nothing_installed_gives_only_nulls(messages):
    m = validate_message(messages[2], received_at=NOW, data_source="hardware").measurement
    assert m.current_a is None and m.battery_voltage_v is None and m.panel_temperature_c is None
    assert m.battery_energy_in_wh is None and m.data_completeness == 0


def test_mcu_config_message_is_accepted_by_backend(messages):
    cfg = messages[3]
    merged = SystemConfig(**{**SystemConfig().model_dump(), "panel_power_w": cfg["panel_power_w"],
                             "panel_count": cfg["panel_count"]})
    assert cfg["schema_version"] == 1 and merged.panel_count == 12 and merged.panel_power_w == 455
