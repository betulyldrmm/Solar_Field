"""Schema v2 (5-minute window summaries): validator, migration of old databases,
CSV layout, simulator output, energy separation and the MCU config path."""

import csv
import json
import sqlite3
from datetime import UTC, datetime, timedelta

import pytest

from app.models.schemas import SystemConfig
from app.services.bridge_service import HardwareBridgeAdapter
from app.services.energy_calculator import daily_energy
from app.services.ingest import IngestService
from app.services.validator import validate_message
from app.simulation.simulator import Simulator
from app.storage.csv_logger import CSV_FIELDS, CsvLogger
from app.storage.database import MIGRATIONS, Database

NOW = datetime(2026, 11, 28, 10, 0, tzinfo=UTC)


def v2(**over):
    base = {
        "schema_version": 2, "boot_id": "a1b2c3d4", "sequence": 12, "uptime_ms": 3_600_000,
        "window_s": 300, "samples_expected": 60, "data_completeness": 1.0,
        "voltage_v": 0.021, "current_a": 0.0712, "power_w": 0.0015,
        "panel_temperature_c": 25.4, "ambient_temperature_c": 15.2, "case_temperature_c": 22.8,
        "battery_voltage_v": 11.82, "battery_current_a": 0.35,
        "fan_state": False, "fan_on_s": 0, "battery_energy_in_wh": 0.345, "battery_energy_out_wh": 0.0,
        "stats": {
            "current_a": {"min": 0.061, "max": 0.088, "n": 60},
            "panel_temperature_c": {"min": 24.9, "max": 26.0, "n": 60},
            "battery_voltage_v": {"min": 11.80, "max": 11.84, "n": 60},
        },
        "sensor_status": "OK",
        "sensors": {"ina_ref": "OK", "ina_batt": "OK", "t_panel": "OK", "t_ambient": "OK", "t_case": "OK"},
    }
    base.update(over)
    return base


# ---------------------------------------------------------------- validator
def test_valid_window_summary():
    r = validate_message(v2(), received_at=NOW, data_source="hardware")
    m = r.measurement
    assert r.issues == []
    assert m.schema_version == 2 and m.window_s == 300 and m.samples_expected == 60
    assert m.data_completeness == 1.0 and m.battery_energy_in_wh == pytest.approx(0.345)
    assert m.stats["current_a"] == {"min": 0.061, "max": 0.088, "n": 60}
    assert m.current_a == 0.0712  # the mean


def test_incomplete_window_is_flagged_not_dropped():
    m = validate_message(v2(data_completeness=0.6), received_at=NOW, data_source="hardware").measurement
    assert "window_incomplete" in m.quality_flags and m.current_a is not None


def test_failed_sensor_also_drops_its_min_max():
    raw = v2(panel_temperature_c=None, sensors={"t_panel": "DISCONNECTED"})
    r = validate_message(raw, received_at=NOW, data_source="hardware")
    assert r.measurement.panel_temperature_c is None
    assert r.measurement.stats["panel_temperature_c"]["min"] is None


def test_inconsistent_min_max_rejected_but_mean_kept():
    raw = v2(stats={"current_a": {"min": 0.09, "max": 0.05, "n": 60}})
    r = validate_message(raw, received_at=NOW, data_source="hardware")
    assert r.measurement.current_a == 0.0712
    assert r.measurement.stats["current_a"]["min"] is None
    assert any("stats.current_a" in i.error for i in r.issues)


def test_battery_energy_needs_working_battery_sensor_and_sane_range():
    raw = v2(sensors={"ina_batt": "ERROR"})
    m = validate_message(raw, received_at=NOW, data_source="hardware").measurement
    assert m.battery_energy_in_wh is None and m.battery_voltage_v is None
    r = validate_message(v2(battery_energy_in_wh=999), received_at=NOW, data_source="hardware")
    assert r.measurement.battery_energy_in_wh is None and r.issues


def test_bad_window_length_flagged():
    m = validate_message(v2(window_s=0), received_at=NOW, data_source="hardware").measurement
    assert m.window_s is None and "window_invalid" in m.quality_flags


def test_v1_messages_still_accepted():
    raw = {"schema_version": 1, "boot_id": "b", "sequence": 1, "current_a": 0.07, "voltage_v": 0.02}
    m = validate_message(raw, received_at=NOW, data_source="hardware").measurement
    assert m.schema_version == 1 and m.window_s is None and m.stats == {}


# ---------------------------------------------------------------- migration
def test_old_v1_database_is_migrated_without_touching_rows(tmp_path):
    path = tmp_path / "old.db"
    con = sqlite3.connect(path)
    con.executescript("BEGIN;" + MIGRATIONS[0] + "PRAGMA user_version = 1;COMMIT;")
    con.execute(
        "INSERT INTO measurements (timestamp_utc, boot_id, sequence, voltage_v, current_a, power_w, "
        "sensor_status, data_source) VALUES ('2026-11-20T10:00:00.000Z', 'old', 5, 0.02, 0.07, 0.0014, "
        "'OK', 'hardware')")
    con.commit()
    con.close()

    db = Database(path)
    assert db.schema_version() == len(MIGRATIONS) == 2
    old = db.latest_measurement()
    assert old.boot_id == "old" and old.current_a == 0.07
    assert old.schema_version == 1 and old.window_s is None and old.stats == {}

    new = validate_message(v2(), received_at=NOW, data_source="hardware").measurement
    db.insert_measurement(new)
    assert db.latest_measurement() == new
    assert db.count_measurements() == 2


# -------------------------------------------------------------------- CSV
def test_csv_has_window_columns(tmp_path):
    log = CsvLogger(tmp_path, fsync_every=1, min_free_mb=0)
    m = validate_message(v2(), received_at=NOW, data_source="hardware").measurement
    path = log.append(m)
    row = next(csv.DictReader(path.open()))
    assert row["schema_version"] == "2" and row["window_s"] == "300"
    assert row["battery_energy_in_wh"] == "0.345" and row["current_a_min"] == "0.061"


def test_old_csv_file_of_the_same_day_is_not_mixed(tmp_path):
    old = tmp_path / f"measurements_{NOW.date().isoformat()}.csv"
    old_header = CSV_FIELDS[:15]
    old.write_text(",".join(old_header) + "\n" + ",".join(["x"] * 15) + "\n")
    before = old.read_text()
    path = CsvLogger(tmp_path, fsync_every=1, min_free_mb=0).append(
        validate_message(v2(), received_at=NOW, data_source="hardware").measurement)
    assert path.name.endswith("_v2.csv") and old.read_text() == before


# -------------------------------------------------------------- simulator
def test_simulator_emits_valid_v2_windows():
    sim = Simulator(latitude_deg=41.7, longitude_deg=27.2, seed=4, fault_rate=0, drop_rate=0)
    sim.sample(NOW - timedelta(minutes=5))
    raw = sim.sample(NOW)
    assert raw["schema_version"] == 2 and raw["window_s"] == 300 and raw["samples_expected"] == 60
    st = raw["stats"]["current_a"]
    assert st["n"] == 60 and st["min"] <= raw["current_a"] <= st["max"]
    r = validate_message(raw, received_at=NOW, data_source="simulation")
    assert r.issues == [] and r.measurement.battery_energy_in_wh is not None


# --------------------------------------------- irradiance vs electrical energy
def test_battery_energy_is_reported_separately_from_irradiance(tmp_path):
    db = Database(tmp_path / "e.db")
    ingest = IngestService(db, None, "simulation")
    sim = Simulator(latitude_deg=41.735, longitude_deg=27.225, seed=7, fault_rate=0, drop_rate=0)
    t = datetime(2026, 6, 20, 2, 0, tzinfo=UTC)  # 05:00 local, before sunrise
    while t < datetime(2026, 6, 20, 19, 0, tzinfo=UTC):
        ingest.ingest(sim.sample(t), received_at=t)
        t += timedelta(minutes=5)
    day = daily_energy(db.query_measurements(), SystemConfig(), latitude_deg=41.735, longitude_deg=27.225,
                       timezone="Europe/Istanbul")[0]
    assert day.insolation_kwh_m2 and day.insolation_kwh_m2 > 3          # summer day, from reference Isc
    assert day.battery_energy_in_wh and day.battery_energy_in_wh > 10   # measured charge energy, Wh
    assert day.battery_energy_out_wh and day.battery_energy_out_wh > 0
    assert day.reference_energy_wh < 0.1                                # short-circuited -> ~0, diagnostic


# ---------------------------------------------------------- MCU config path
def test_encoder_edit_from_station_updates_only_panel_fields(tmp_path):
    db = Database(tmp_path / "c.db")
    db.save_config(SystemConfig(fan_on_c=45, fan_off_c=40))
    seen = []
    adapter = HardwareBridgeAdapter(IngestService(db, None, "hardware"), on_config_saved=seen.append)
    assert adapter.on_mcu_config(json.dumps({"schema_version": 1, "panel_power_w": 550, "panel_count": 12}))
    cfg = db.load_config()
    assert (cfg.panel_power_w, cfg.panel_count, cfg.fan_on_c) == (550, 12, 45)
    assert seen and seen[0].panel_count == 12


@pytest.mark.parametrize("payload", [
    '{"schema_version": 1, "panel_power_w": 0}', '{"schema_version": 1, "panel_count": 20000}',
    '{"schema_version": 9, "panel_count": 3}', '{"schema_version": 1}', "not json",
])
def test_bad_mcu_config_rejected_and_logged(tmp_path, payload):
    db = Database(tmp_path / "c.db")
    before = db.load_config()
    assert not HardwareBridgeAdapter(IngestService(db, None, "hardware")).on_mcu_config(payload)
    assert db.load_config() == before
    assert any(e["kind"] == "mcu_config_rejected" for e in db.recent_events())


def test_config_for_mcu_contains_window_and_fan_limits():
    out = json.loads(HardwareBridgeAdapter.config_for_mcu(SystemConfig()))
    assert out["measurement_interval_s"] == 300 and out["fan_on_c"] == 40 and out["panel_count"] == 8


def test_measurement_receipt_true_for_stored_duplicate_and_rejected(tmp_path):
    db = Database(tmp_path / "r.db")
    adapter = HardwareBridgeAdapter(IngestService(db, None, "hardware"))
    msg = json.dumps(v2())
    assert adapter.on_measurement(msg) is True           # stored
    assert adapter.on_measurement(msg) is True           # duplicate: already stored -> don't resend
    assert adapter.on_measurement('{"schema_version": 99}') is True  # rejected: resending cannot help
    assert db.count_measurements() == 1


def test_measurement_receipt_false_on_transient_error(tmp_path):
    db = Database(tmp_path / "r.db")
    adapter = HardwareBridgeAdapter(IngestService(db, None, "hardware"))
    db.close()  # simulate a database failure
    assert adapter.on_measurement(json.dumps(v2())) is False


def test_boot_ids_are_fresh_8_hex_and_logged(tmp_path):
    db = Database(tmp_path / "b.db")
    adapter = HardwareBridgeAdapter(IngestService(db, None, "hardware"))
    ids = {adapter.on_boot_id_request() for _ in range(50)}
    assert len(ids) == 50 and all(len(i) == 8 and int(i, 16) >= 0 for i in ids)
    assert sum(e["kind"] == "device_boot" for e in db.recent_events()) == 50
