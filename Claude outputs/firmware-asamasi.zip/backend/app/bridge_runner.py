"""Linux-side entry point on the Arduino UNO Q: STM32 Bridge -> ingest pipeline.

    python -m app.bridge_runner          (on the UNO Q, SFS_DATA_MODE=hardware)

Uses the official `arduino.app_utils` API (Bridge.provide / Bridge.call, App.run),
which exists only on the UNO Q (installed with App Lab / arduino-router).
FastAPI (uvicorn) and the BLE peripheral run as separate processes and read the
same SQLite database.

DOĞRULAMA GEREKİYOR (not run on hardware yet):
* running outside App Lab: the arduino-router service must be up
  (/var/run/arduino-router.sock); App Lab normally starts python/main.py itself.
* Bridge payload size for the ~700-byte window JSON.
"""

from __future__ import annotations

import logging
import sys
import time

from app.config import Settings
from app.services.bridge_service import HardwareBridgeAdapter
from app.services.ingest import IngestService
from app.storage.csv_logger import CsvLogger
from app.storage.database import Database

log = logging.getLogger("sfs.bridge")
CONFIG_PUSH_RETRY_S = 30


def main() -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    try:
        from arduino.app_utils import App, Bridge  # type: ignore[import-not-found]
    except ImportError:
        log.error("arduino.app_utils yok: bu betik yalnızca Arduino UNO Q üzerinde çalışır.")
        return 2

    settings = Settings.from_env()
    if settings.data_mode != "hardware":
        log.warning("SFS_DATA_MODE=%s — gerçek sensör verisi için 'hardware' olmalı", settings.data_mode)
    db = Database(settings.db_path)
    csv_logger = CsvLogger(settings.csv_dir, settings.csv_fsync_every, settings.min_free_disk_mb)
    ingest = IngestService(db, csv_logger, settings.data_mode)
    state: dict[str, object] = {"sent": None, "last_try": 0.0}

    def push_config_if_changed() -> None:
        # The API (another process) may change the config at any time -> compare and resend.
        payload = HardwareBridgeAdapter.config_for_mcu(db.load_config())
        if payload == state["sent"] or time.monotonic() - float(state["last_try"]) < CONFIG_PUSH_RETRY_S \
                and state["sent"] is None:
            return
        state["last_try"] = time.monotonic()
        try:
            Bridge.call("set_config", payload)
            state["sent"] = payload
            log.info("config sent to STM32")
        except Exception as exc:  # noqa: BLE001 — MCU may still be booting
            log.warning("set_config failed (%s), will retry", exc)

    adapter = HardwareBridgeAdapter(ingest)
    Bridge.provide("new_boot_id", adapter.on_boot_id_request)
    Bridge.provide("measurement", adapter.on_measurement)
    Bridge.provide("mcu_config", adapter.on_mcu_config)
    db.add_event("info", "bridge_start", f"mode={settings.data_mode}")

    def loop() -> None:
        push_config_if_changed()
        time.sleep(5)

    App.run(user_loop=loop)
    return 0


if __name__ == "__main__":
    sys.exit(main())
