"""Append-only CSV log, one file per UTC day (measurements_YYYY-MM-DD.csv).

CSV is the human-readable backup next to SQLite. Daily files limit the damage
of a corrupted file to one day, and make copying data off the device easy.

Columns were extended for schema v2 (window summaries). A day file written by
an older version keeps its old header untouched; new rows for that day go to
measurements_YYYY-MM-DD_v2.csv instead of mixing two layouts in one file.
"""

from __future__ import annotations

import csv
import io
import os
import shutil
from collections.abc import Iterable
from pathlib import Path

from app.models.schemas import Measurement

CSV_FIELDS = [
    "timestamp_utc", "sequence", "voltage_v", "current_a", "power_w",
    "panel_temperature_c", "ambient_temperature_c", "case_temperature_c",
    "battery_voltage_v", "battery_current_a", "fan_state", "sensor_status",
    "data_source", "boot_id", "quality_flags",
    # schema v2 (window summary)
    "schema_version", "window_s", "samples_expected", "data_completeness", "fan_on_s",
    "battery_energy_in_wh", "battery_energy_out_wh",
    "current_a_min", "current_a_max", "panel_temperature_c_min", "panel_temperature_c_max",
    "battery_voltage_v_min", "battery_voltage_v_max", "battery_current_a_min", "battery_current_a_max",
]
_STAT_COLUMNS = ["current_a", "panel_temperature_c", "battery_voltage_v", "battery_current_a"]


class DiskSpaceLow(OSError):
    pass


def measurement_to_row(m: Measurement) -> dict[str, str]:
    def fmt(v: float | None) -> str:
        return "" if v is None else f"{v:.6g}"

    return {
        "timestamp_utc": m.timestamp_utc.isoformat(timespec="milliseconds"),
        "sequence": str(m.sequence),
        "voltage_v": fmt(m.voltage_v),
        "current_a": fmt(m.current_a),
        "power_w": fmt(m.power_w),
        "panel_temperature_c": fmt(m.panel_temperature_c),
        "ambient_temperature_c": fmt(m.ambient_temperature_c),
        "case_temperature_c": fmt(m.case_temperature_c),
        "battery_voltage_v": fmt(m.battery_voltage_v),
        "battery_current_a": fmt(m.battery_current_a),
        "fan_state": "" if m.fan_state is None else ("1" if m.fan_state else "0"),
        "sensor_status": m.sensor_status,
        "data_source": m.data_source,
        "boot_id": m.boot_id,
        "quality_flags": "|".join(m.quality_flags),
        "schema_version": str(m.schema_version),
        "window_s": fmt(m.window_s),
        "samples_expected": "" if m.samples_expected is None else str(m.samples_expected),
        "data_completeness": fmt(m.data_completeness),
        "fan_on_s": fmt(m.fan_on_s),
        "battery_energy_in_wh": fmt(m.battery_energy_in_wh),
        "battery_energy_out_wh": fmt(m.battery_energy_out_wh),
        **{f"{c}_{k}": fmt(_stat(m, c, k)) for c in _STAT_COLUMNS for k in ("min", "max")},
    }


def _stat(m: Measurement, channel: str, key: str) -> float | None:
    v = m.stats.get(channel, {}).get(key)
    return None if v is None else float(v)


def to_csv_text(measurements: Iterable[Measurement]) -> str:
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=CSV_FIELDS, lineterminator="\n")
    w.writeheader()
    for m in measurements:
        w.writerow(measurement_to_row(m))
    return buf.getvalue()


class CsvLogger:
    def __init__(self, directory: Path, fsync_every: int = 12, min_free_mb: int = 200):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.fsync_every = max(1, fsync_every)
        self.min_free_mb = min_free_mb
        self._pending = 0

    def path_for(self, m: Measurement) -> Path:
        base = self.directory / f"measurements_{m.timestamp_utc.date().isoformat()}.csv"
        if base.exists() and base.stat().st_size > 0:
            with base.open(encoding="utf-8") as f:
                header = f.readline().strip().split(",")
            if header != CSV_FIELDS:  # file from an older version: never append a different layout
                return base.with_name(base.stem + "_v2.csv")
        return base

    def free_mb(self) -> float:
        return shutil.disk_usage(self.directory).free / (1024 * 1024)

    def append(self, m: Measurement) -> Path:
        if self.free_mb() < self.min_free_mb:
            raise DiskSpaceLow(f"free disk below {self.min_free_mb} MB, CSV write skipped")
        path = self.path_for(m)
        new_file = not path.exists() or path.stat().st_size == 0
        with path.open("a", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=CSV_FIELDS, lineterminator="\n")
            if new_file:
                w.writeheader()
            w.writerow(measurement_to_row(m))
            self._pending += 1
            if new_file or self._pending >= self.fsync_every:
                f.flush()
                os.fsync(f.fileno())
                self._pending = 0
        return path
