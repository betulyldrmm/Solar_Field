"""Measurement sources: simulator (now) and Arduino UNO Q Bridge (hardware).

The hardware path is a thin adapter with NO dependency on the Arduino Python
package, so the backend stays testable on a PC. The Bridge wiring itself is in
app/bridge_runner.py (runs only on the UNO Q).

Bridge contract (firmware/solar_field_station/src/hal/bridge_link.cpp):
    STM32 -> Linux  Bridge.call("new_boot_id")           once per STM32 boot -> 8 hex chars
    STM32 -> Linux  Bridge.call("measurement", json)     every window (schema v2) -> receipt bool
    STM32 -> Linux  Bridge.call("mcu_config", json)      after an encoder edit -> bool
    Linux -> STM32  Bridge.call("set_config", json)      at start / after a config change

API names from the official Arduino_RouterBridge / arduino.app_utils examples.
DOĞRULAMA GEREKİYOR: not yet run on a real UNO Q.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import secrets
from collections.abc import Callable
from datetime import UTC, datetime

from app.models.schemas import SystemConfig
from app.services.ingest import IngestService
from app.simulation.simulator import Simulator

log = logging.getLogger(__name__)


MCU_CONFIG_SCHEMA = 1


class HardwareBridgeAdapter:
    """Glue between the UNO Q Bridge callbacks and the ingest pipeline / config store."""

    def __init__(self, ingest: IngestService, on_config_saved: Callable[[SystemConfig], None] | None = None):
        self.ingest = ingest
        self.on_config_saved = on_config_saved
        self.last_message_utc: datetime | None = None

    def on_boot_id_request(self) -> str:
        """A fresh random boot id for a just-started STM32 (8 hex chars, matches the
        8-byte boot_id field of the BLE record). The STM32 has no verified entropy
        source; a repeated id would make (boot_id, sequence) collide with old rows."""
        boot_id = secrets.token_hex(4)
        self.ingest.db.add_event("info", "device_boot", f"STM32 started, boot_id {boot_id}")
        return boot_id

    def on_measurement(self, payload: str) -> bool:
        """Called from the Bridge with the STM32's JSON string.

        The return value is the firmware's delivery receipt: True = "handled, drop
        it from your queue" (stored, a duplicate already stored, or rejected by the
        validator — resending a rejected message would never succeed). False only
        for a transient failure (e.g. database error): the STM32 keeps the window
        and retries."""
        self.last_message_utc = datetime.now(UTC)
        try:
            self.ingest.ingest(payload, received_at=self.last_message_utc)
        except Exception:  # noqa: BLE001 — must answer the Bridge, never raise into it
            log.exception("ingest failed, STM32 will retry")
            return False
        return True

    def on_mcu_config(self, payload: str) -> bool:
        """Panel power / count edited with the encoder on the station.

        Only those two fields are taken from the MCU; everything else stays as
        stored. Invalid values are rejected (logged), never half-applied."""
        db = self.ingest.db
        try:
            raw = json.loads(payload)
            if raw.get("schema_version") != MCU_CONFIG_SCHEMA:
                raise ValueError(f"unsupported mcu_config schema {raw.get('schema_version')!r}")
            update = {k: raw[k] for k in ("panel_power_w", "panel_count") if k in raw}
            if not update:
                raise ValueError("no editable field")
            cfg = SystemConfig(**{**db.load_config().model_dump(), **update})
        except (ValueError, TypeError, AttributeError) as exc:  # pydantic ValidationError is a ValueError
            db.add_event("warning", "mcu_config_rejected", str(exc)[:300])
            return False
        db.save_config(cfg)
        db.add_event("info", "mcu_config", f"from station: {update}")
        if self.on_config_saved is not None:
            self.on_config_saved(cfg)
        return True

    @staticmethod
    def config_for_mcu(cfg: SystemConfig) -> str:
        """Compact JSON for the STM32 (LCD values, window length, local safety thresholds)."""
        return json.dumps(
            {
                "schema_version": 1,
                "panel_power_w": cfg.panel_power_w,
                "panel_count": cfg.panel_count,
                "installed_kwp": round(cfg.kwp, 3),
                "measurement_interval_s": cfg.measurement_interval_s,
                "fan_on_c": cfg.fan_on_c,
                "fan_off_c": cfg.fan_off_c,
            },
            separators=(",", ":"),
        )


class SimulationRunner:
    """Feeds the simulator into the ingest pipeline at the configured interval."""

    def __init__(
        self,
        simulator: Simulator,
        ingest: IngestService,
        interval_s: float,
        is_on: Callable[[datetime], bool] | None = None,
    ):
        self.simulator = simulator
        self.ingest = ingest
        self.interval_s = interval_s
        self.is_on = is_on or (lambda _when: True)  # night-shutdown schedule
        self._task: asyncio.Task[None] | None = None

    def step(self, when: datetime | None = None) -> bool:
        when = when or datetime.now(UTC)
        if not self.is_on(when):
            self.simulator.power_off(when)  # station is off at night -> no data
            return False
        self.simulator.power_on(when)
        msg = self.simulator.sample(when)
        if msg is None:
            return False
        return self.ingest.ingest(msg, received_at=when).stored

    async def _loop(self) -> None:
        while True:
            try:
                await asyncio.to_thread(self.step)
            except Exception:  # keep the logger alive; errors are logged
                log.exception("simulation step failed")
            await asyncio.sleep(self.interval_s)

    def start(self) -> None:
        if self._task is None:
            self._task = asyncio.create_task(self._loop())

    async def stop(self) -> None:
        if self._task is not None:
            self._task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._task
            self._task = None
