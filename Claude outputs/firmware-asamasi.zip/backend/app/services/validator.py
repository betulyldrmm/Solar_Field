"""Validates raw STM32 messages (schema v1 and v2) into Measurement rows.

v1: one instantaneous sample. v2: a window summary (means + per-channel
min/max/n, battery energy, completeness) — see docs/architecture.md.

Rules:
* Structural problems (wrong schema, missing sequence) -> message rejected.
* Field problems (out of range, sensor fault sentinel, sensor reported failed)
  -> that field becomes None and a SensorIssue is recorded. A bad value is
  never stored as if it were a real measurement.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from app.config import SUPPORTED_SCHEMA_VERSIONS
from app.models.schemas import Measurement

# DS18B20 sentinels: -127 = DEVICE_DISCONNECTED_C, 85.0 = power-on reset value
DS18B20_DISCONNECTED_C = -127.0
DS18B20_POWER_ON_RESET_C = 85.0

# field -> (sensor id, min, max)
FIELD_RULES: dict[str, tuple[str, float, float]] = {
    "voltage_v": ("ina_ref", -0.1, 36.0),  # INA226 bus voltage limit 36 V
    "current_a": ("ina_ref", -0.05, 2.0),
    "power_w": ("ina_ref", -0.5, 50.0),
    "battery_voltage_v": ("ina_batt", 0.0, 36.0),
    "battery_current_a": ("ina_batt", -10.0, 10.0),
    "panel_temperature_c": ("t_panel", -40.0, 100.0),
    "ambient_temperature_c": ("t_ambient", -40.0, 70.0),
    "case_temperature_c": ("t_case", -40.0, 100.0),
}
TEMP_FIELDS = {"panel_temperature_c", "ambient_temperature_c", "case_temperature_c"}
OK_STATES = {"OK"}
EARLIEST_VALID_TIME = datetime(2025, 1, 1, tzinfo=UTC)


class MessageRejected(ValueError):
    """The message cannot be stored at all."""


@dataclass
class SensorIssue:
    sensor: str
    error: str


@dataclass
class ValidationResult:
    measurement: Measurement
    issues: list[SensorIssue] = field(default_factory=list)


def _as_float(value: Any) -> float | None:
    if value is None or isinstance(value, bool):
        return None
    try:
        f = float(value)
    except (TypeError, ValueError):
        return None
    return f if math.isfinite(f) else None


def validate_message(
    raw: dict[str, Any], *, received_at: datetime, data_source: str
) -> ValidationResult:
    if not isinstance(raw, dict):
        raise MessageRejected("message is not a JSON object")
    version = raw.get("schema_version")
    if version not in SUPPORTED_SCHEMA_VERSIONS or isinstance(version, bool):
        raise MessageRejected(
            f"unsupported schema_version {version!r}, expected one of {SUPPORTED_SCHEMA_VERSIONS}"
        )
    seq = raw.get("sequence")
    if not isinstance(seq, int) or isinstance(seq, bool) or seq < 0:
        raise MessageRejected("sequence must be a non-negative integer")
    if received_at.tzinfo is None:
        raise MessageRejected("received_at must be timezone-aware")

    issues: list[SensorIssue] = []
    flags: list[str] = []
    sensor_states_raw = raw.get("sensors") or {}
    sensor_states = {
        str(k): str(v).upper() for k, v in sensor_states_raw.items()
    } if isinstance(sensor_states_raw, dict) else {}

    values: dict[str, float | None] = {}
    for name, (sensor, lo, hi) in FIELD_RULES.items():
        present = name in raw and raw[name] is not None
        val = _as_float(raw.get(name))
        state = sensor_states.get(sensor, "OK")
        if state not in OK_STATES:
            if present or state != "NOT_INSTALLED":
                issues.append(SensorIssue(sensor, f"{name}: sensor state {state}"))
            values[name] = None
            continue
        if present and val is None:
            issues.append(SensorIssue(sensor, f"{name}: not a finite number"))
        elif val is not None and name in TEMP_FIELDS:
            if val == DS18B20_DISCONNECTED_C:
                issues.append(SensorIssue(sensor, f"{name}: DS18B20 disconnected (-127)"))
                val = None
            elif val == DS18B20_POWER_ON_RESET_C:
                issues.append(SensorIssue(sensor, f"{name}: DS18B20 power-on value 85.0"))
                val = None
        if val is not None and not (lo <= val <= hi):
            issues.append(SensorIssue(sensor, f"{name}: {val} out of range [{lo}, {hi}]"))
            val = None
        values[name] = val

    v, i, p = values["voltage_v"], values["current_a"], values["power_w"]
    if v is not None and i is not None:
        computed = v * i
        if p is None:
            values["power_w"] = computed
            flags.append("power_computed")
        elif abs(p - computed) > max(0.05, 0.05 * abs(computed)):
            flags.append("power_mismatch")
            values["power_w"] = computed
    elif p is not None:
        # power without V or I cannot be cross-checked -> don't trust it
        values["power_w"] = None
        flags.append("power_unverifiable")

    if received_at < EARLIEST_VALID_TIME:
        flags.append("clock_unsynced")

    fan = raw.get("fan_state")
    fan_state = fan if isinstance(fan, bool) else None

    status = str(raw.get("sensor_status") or "OK").upper()
    if issues and status == "OK":
        status = "DEGRADED"

    window = _validate_window(raw, values, sensor_states, issues, flags) if version == 2 else {}

    m = Measurement(
        timestamp_utc=received_at.astimezone(UTC),
        boot_id=str(raw.get("boot_id") or "unknown")[:32],
        sequence=seq,
        fan_state=fan_state,
        sensor_status=status,
        sensor_states=sensor_states,
        quality_flags=flags,
        data_source=data_source,  # type: ignore[arg-type]
        schema_version=version,
        **values,
        **window,
    )
    return ValidationResult(measurement=m, issues=issues)


# ------------------------------------------------------------------ schema v2
STAT_CHANNELS = {  # stats key -> value field it summarises
    "voltage_v": "voltage_v", "current_a": "current_a",
    "panel_temperature_c": "panel_temperature_c", "ambient_temperature_c": "ambient_temperature_c",
    "case_temperature_c": "case_temperature_c",
    "battery_voltage_v": "battery_voltage_v", "battery_current_a": "battery_current_a",
}
MAX_WINDOW_ENERGY_WH = 50.0  # far above anything a 20 W panel can move in one window


def _validate_window(raw: dict[str, Any], values: dict[str, float | None], sensor_states: dict[str, str],
                     issues: list[SensorIssue], flags: list[str]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    window_s = _as_float(raw.get("window_s"))
    if window_s is None or not 1 <= window_s <= 3600:
        flags.append("window_invalid")
        window_s = None
    out["window_s"] = window_s

    expected = raw.get("samples_expected")
    out["samples_expected"] = expected if isinstance(expected, int) and not isinstance(expected, bool) \
        and 0 < expected <= 10000 else None

    comp = _as_float(raw.get("data_completeness"))
    out["data_completeness"] = comp if comp is not None and 0 <= comp <= 1 else None
    if out["data_completeness"] is not None and out["data_completeness"] < 0.9:
        flags.append("window_incomplete")

    fan_on = _as_float(raw.get("fan_on_s"))
    out["fan_on_s"] = fan_on if fan_on is not None and fan_on >= 0 and \
        (window_s is None or fan_on <= window_s + 1) else None

    batt_ok = sensor_states.get("ina_batt", "OK") in OK_STATES
    for key in ("battery_energy_in_wh", "battery_energy_out_wh"):
        e = _as_float(raw.get(key))
        if e is not None and not (0 <= e <= MAX_WINDOW_ENERGY_WH):
            issues.append(SensorIssue("ina_batt", f"{key}: {e} out of range"))
            e = None
        out[key] = e if batt_ok else None

    stats_raw = raw.get("stats") if isinstance(raw.get("stats"), dict) else {}
    stats: dict[str, dict[str, float | int | None]] = {}
    for key, field_name in STAT_CHANNELS.items():
        entry = stats_raw.get(key)
        if not isinstance(entry, dict):
            continue
        sensor, lo, hi = FIELD_RULES[field_name]
        n = entry.get("n")
        n = n if isinstance(n, int) and not isinstance(n, bool) and n >= 0 else None
        mn, mx = _as_float(entry.get("min")), _as_float(entry.get("max"))
        if values.get(field_name) is None or not n:
            # mean rejected / sensor failed / no samples -> min/max are not trustworthy either
            mn = mx = None
        elif mn is None or mx is None or not (lo <= mn <= mx <= hi):
            issues.append(SensorIssue(sensor, f"stats.{key}: inconsistent min/max"))
            mn = mx = None
        stats[key] = {"min": mn, "max": mx, "n": n}
    out["stats"] = stats
    return out
