# STM32 firmware

Kod: `firmware/solar_field_station/` · Testler: `firmware/test/`

> **Durum:** Mantık katmanı bilgisayarda sahte donanımla test edildi (30 C++ test,
> 147 kontrol) ve ürettiği JSON Python doğrulayıcısından geçiyor. **Gerçek UNO Q
> için derlenmedi, karta yüklenmedi, sensörlerle denenmedi.** Pinler ve adresler
> atanmadı; bu yüzden kart üzerinde şu an tüm sensörler `NOT_INSTALLED` raporlar.

## Ne yapar

| Aralık | İş |
|---|---|
| Her 5 s | 2× INA226 (referans panel Isc + pil V/I), 3× DS18B20 (panel/ortam/kasa) okunur; fan kontrolü; pencere istatistiğine eklenir |
| Her 5 dk (`measurement_interval_s`) | Pencere özeti: her kanal için ortalama, min, max, örnek sayısı; pil şarj/deşarj enerjisi (Wh); fan çalışma süresi; veri tamlığı → schema v2 JSON → Bridge → Linux (SQLite + CSV) |
| Sürekli | Enkoder: panel gücü / panel sayısı ayarı → Linux'a `mcu_config`; LCD (ST7920 onaylanırsa) |

Linux kapalıyken ölçüm durmaz: teslim edilemeyen pencereler 12'lik kuyrukta (1 saat)
bekler, 10 s'de bir tekrar denenir; kuyruk dolarsa **en eski** pencere düşer.

## Katmanlar

```text
solar_field_station.ino   nesneleri kurar, setup()/loop()
src/config/board_config.h tek donanım dosyası (pin, I2C bus, adres, şönt, ROM kodları)
src/core/                 Arduino'suz mantık → bilgisayarda test edilir
  window_aggregator       5 s örnek → 5 dk özet (ort/min/max/n, enerji, tamlık)
  fan_controller          histerezis, en kısa kapanma süresi, sensör arızasında fan AÇIK, 70 °C acil
  input, menu             enkoder kod çözme, buton (tık / uzun bas), ayar menüsü
  messages, json_util     schema v2 JSON (float printf'e bağımlı değil), set_config ayrıştırma
  display_model           128×64 ekranın 6×21 karakterlik metni
  station_app             hepsini zamanlayan ana döngü, Linux kuyruğu, boot_id
src/hal/                  donanım: ina226, ds18b20_sensors, simple_io (fan, enkoder), lcd_st7920, bridge_link
```

Donanım değişirse yalnızca `board_config.h` ve gerekirse ilgili `hal/` dosyası değişir.

## Birimler ve ışınım / enerji ayrımı

- Referans panel **kısa devre** çalışır: `current_a` = Isc → ışınım vekili. Işınım (W/m², kWh/m²) Linux'ta
  `energy_calculator` ile hesaplanır ve "tahmini/hesaplanan" etiketlenir. Referans panelin `power_w` değeri
  yalnızca tanılamadır (≈0), **elektrik üretimi değildir**.
- Gerçekten **ölçülen elektrik enerjisi** pil tarafıdır: `battery_energy_in_wh` (şarj) ve
  `battery_energy_out_wh` (deşarj), her 5 s örnekte `P = V·I`, `E += P·Δt`. Örnek boşlukları enerji sayılmaz
  (Δt en fazla 2 örnek aralığı). Günlük toplamlar API'de `DailyEnergy.battery_energy_*_wh` olarak ayrı alanlardır.
- Akımın işareti (`SFS_BATT_CURRENT_SIGN`) şarjın pozitif olacağı şekilde ayarlanmalıdır.

## STM32 ↔ Linux (Bridge)

Resmi `Arduino_RouterBridge` (STM32) ve `arduino.app_utils` (Linux) API'si:

| Yön | Çağrı | İçerik |
|---|---|---|
| STM32 → Linux | `Bridge.call("new_boot_id").result(id)` | Her açılışta bir kez; Linux 8 hex karakter üretir |
| STM32 → Linux | `Bridge.call("measurement", json).result(ok)` | Pencere özeti; `ok` = teslim alındı (kaydedildi / zaten vardı / reddedildi) |
| STM32 → Linux | `Bridge.call("mcu_config", json).result(ok)` | Enkoderle değiştirilen panel gücü/sayısı |
| Linux → STM32 | `Bridge.call("set_config", json)` → `provide_safe` | Panel, pencere uzunluğu, fan eşikleri |

Linux tarafı: `python -m app.bridge_runner` (yalnızca UNO Q'da çalışır).
**boot_id neden Linux'tan?** STM32'de doğrulanmış bir rastgelelik kaynağı yok; açılıştan açılışa tekrar eden bir
boot_id, veritabanında `(boot_id, sequence)` çakışmasıyla yeni pencerelerin "kopya" sayılıp atılmasına yol açardı.

### measurement (schema v2) örneği

```json
{"schema_version":2,"boot_id":"a1b2c3d4","sequence":12,"uptime_ms":3601000,
 "window_s":300.0,"samples_expected":60,"data_completeness":1.000,
 "voltage_v":0.0213,"current_a":0.071200,"power_w":0.001517,
 "panel_temperature_c":25.40,"ambient_temperature_c":15.20,"case_temperature_c":22.80,
 "battery_voltage_v":11.820,"battery_current_a":0.3500,
 "fan_state":false,"fan_on_s":0.0,"battery_energy_in_wh":0.34500,"battery_energy_out_wh":0.00000,
 "stats":{"current_a":{"min":0.061000,"max":0.088000,"n":60}, "...": "her kanal için"},
 "sensor_status":"OK","sensors":{"ina_ref":"OK","ina_batt":"OK","t_panel":"OK","t_ambient":"OK","t_case":"OK"}}
```

Çalışmayan sensörün ortalaması, min/max'ı ve (pil sensörüyse) enerjisi `null` gönderilir — asla 0 değil.

## Linux tarafındaki değişiklikler (geriye uyumlu)

- **Veritabanı migration v2:** `measurements` tablosuna `schema_version, window_s, samples_expected,
  data_completeness, fan_on_s, battery_energy_in_wh, battery_energy_out_wh, stats` eklendi. Eski satırlar
  dokunulmadan `schema_version=1` olarak kalır (testle doğrulandı).
- **Doğrulayıcı:** v1 ve v2 kabul edilir. Tamlık < %90 → `window_incomplete` bayrağı (kayıt atılmaz).
- **CSV:** yeni sütunlar eklendi; eski düzende bir günlük dosya varsa yeni satırlar `..._v2.csv`'ye yazılır.
- **BLE geçmiş kaydı v2** (76 bayt, pencere alanları dahil); PC eski 40 baytlık v1 paketleri de okur.
- **Simülatör** artık 5 s örneklerden 5 dk özet üretir (donanımla aynı yol).
- `on_measurement` dönüşü teslim makbuzudur: kopya ve reddedilen mesaj da `True` (STM32 boşuna tekrar göndermesin).

## Testler

```bash
cd firmware/test
make              # 30 C++ birim testi (AddressSanitizer + UBSan ile)
make json         # testler + Python sözleşme testi için örnek mesajlar
make hal-syntax   # hal/ ve .ino'yu taklit başlıklarla derleme denetimi (davranış testi DEĞİL)
cd ../../backend && pytest -q   # 113 test; firmware sözleşme testi g++ varsa otomatik çalışır
```

## Donanım gelince (bring-up) — DOĞRULAMA GEREKİYOR

1. **Derleme:** App Lab'de sketch olarak derle. Kütüphaneler: `Arduino_RouterBridge`, `OneWire`, (LCD için) `U8g2`.
   OneWire ve U8g2'nin UNO Q (Zephyr tabanlı çekirdek) ile çalıştığı doğrulanmadı.
2. **I2C:** Resmi pinout'tan INA226'ların bağlanacağı konnektörün `Wire`/`Wire1` karşılığını belirle →
   `SFS_I2C_BUS`. Adresleri (A0/A1) ve şönt değerini modülden oku → `SFS_INA_*`.
3. **DS18B20:** `SFS_ONEWIRE_PIN` ata, `SFS_ONEWIRE_SCAN 1` ile ROM kodlarını Monitor'de gör, sensörleri
   tek tek ısıtarak rolleri (panel/ortam/kasa) eşleştir → `SFS_DS18B20_*_ROM`. 4,7 kΩ pull-up gerekli.
4. **Fan:** lojik seviyeli MOSFET kapısı → `SFS_FAN_PIN`. İlk denemede fanı elle kontrol et.
5. **Enkoder:** A/B/SW pinleri; bir tık = kaç adım (`SFS_ENC_STEPS_PER_DETENT`), yön (`SFS_ENC_REVERSE`).
6. **LCD:** Modülün denetleyicisinin ST7920 olduğunu doğrula (12864KBA etiketi tek başına yeterli değil),
   seri mod (PSB=GND), 5 V modülün 3,3 V lojik ile çalışıp çalışmadığını kontrol et → `SFS_LCD_ST7920_CONFIRMED 1`.
7. **Bridge:** `python -m app.bridge_runner` (veya App Lab python/main.py) ile `new_boot_id`, `measurement`,
   `mcu_config`, `set_config` akışını uçtan uca dene; ~750 baytlık String argümanının sorunsuz geçtiğini doğrula.
8. **Pil akım işareti:** şarj sırasında `battery_current_a` pozitif olmalı, değilse `SFS_BATT_CURRENT_SIGN -1`.

Gece kapanma bilinçli olarak bu aşamada geliştirilmedi (güç mimarisi kesinleşmedi).
